package com.janapad.user.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.janapad.user.data.local.PatgramAreaCatalog
import com.janapad.user.data.local.PreferencesManager
import com.janapad.user.data.model.*
import com.janapad.user.data.repository.JanapadRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = JanapadRepository(application.applicationContext)
    private val prefs = PreferencesManager(application.applicationContext)

    val isFirebaseReady: Boolean
        get() = repo.isFirebaseReady

    val themeMode: StateFlow<ThemeMode> = prefs.themeModeFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ThemeMode.SYSTEM)

    val selectedArea: StateFlow<SelectedArea> = prefs.selectedAreaFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SelectedArea())

    private val _news = MutableStateFlow<ResourceState<List<NewsItem>>>(ResourceState.Loading)
    val news: StateFlow<ResourceState<List<NewsItem>>> = _news.asStateFlow()

    private val _notices = MutableStateFlow<ResourceState<List<NoticeItem>>>(ResourceState.Loading)
    val notices: StateFlow<ResourceState<List<NoticeItem>>> = _notices.asStateFlow()

    private val _approvedPosts = MutableStateFlow<ResourceState<List<PublicPost>>>(ResourceState.Loading)
    val approvedPosts: StateFlow<ResourceState<List<PublicPost>>> = _approvedPosts.asStateFlow()

    private val _myPosts = MutableStateFlow<ResourceState<List<PublicPost>>>(ResourceState.Success(emptyList()))
    val myPosts: StateFlow<ResourceState<List<PublicPost>>> = _myPosts.asStateFlow()

    private val _bloodDonors = MutableStateFlow<ResourceState<List<BloodDonor>>>(ResourceState.Loading)
    val bloodDonors: StateFlow<ResourceState<List<BloodDonor>>> = _bloodDonors.asStateFlow()

    private val _jobs = MutableStateFlow<ResourceState<List<JobListing>>>(ResourceState.Loading)
    val jobs: StateFlow<ResourceState<List<JobListing>>> = _jobs.asStateFlow()

    private val _marketplace = MutableStateFlow<ResourceState<List<MarketplaceItem>>>(ResourceState.Loading)
    val marketplace: StateFlow<ResourceState<List<MarketplaceItem>>> = _marketplace.asStateFlow()

    private val _myMarketplace = MutableStateFlow<ResourceState<List<MarketplaceItem>>>(ResourceState.Success(emptyList()))
    val myMarketplace: StateFlow<ResourceState<List<MarketplaceItem>>> = _myMarketplace.asStateFlow()

    private val _lostFound = MutableStateFlow<ResourceState<List<LostFoundItem>>>(ResourceState.Loading)
    val lostFound: StateFlow<ResourceState<List<LostFoundItem>>> = _lostFound.asStateFlow()

    private val _allReports = MutableStateFlow<ResourceState<List<AreaReport>>>(ResourceState.Loading)
    val allReports: StateFlow<ResourceState<List<AreaReport>>> = _allReports.asStateFlow()

    private val _myReports = MutableStateFlow<ResourceState<List<AreaReport>>>(ResourceState.Success(emptyList()))
    val myReports: StateFlow<ResourceState<List<AreaReport>>> = _myReports.asStateFlow()

    private val _notifications = MutableStateFlow<ResourceState<List<AppNotification>>>(ResourceState.Loading)
    val notifications: StateFlow<ResourceState<List<AppNotification>>> = _notifications.asStateFlow()

    private val _areas = MutableStateFlow<List<AreaInfo>>(listOf(PatgramAreaCatalog.defaultPatgramArea))
    val areas: StateFlow<List<AreaInfo>> = _areas.asStateFlow()

    private var userSpecificJobs: MutableList<Job> = mutableListOf()
    private var globalJobs: MutableList<Job> = mutableListOf()

    init {
        startPublicListeners()
    }

    fun startPublicListeners() {
        globalJobs.forEach { it.cancel() }
        globalJobs.clear()

        globalJobs += viewModelScope.launch { repo.observeNews().collect { _news.value = it } }
        globalJobs += viewModelScope.launch { repo.observeNotices().collect { _notices.value = it } }
        globalJobs += viewModelScope.launch { repo.observeApprovedPosts().collect { _approvedPosts.value = it } }
        globalJobs += viewModelScope.launch { repo.observeBloodDonors().collect { _bloodDonors.value = it } }
        globalJobs += viewModelScope.launch { repo.observeJobs().collect { _jobs.value = it } }
        globalJobs += viewModelScope.launch { repo.observeApprovedMarketplace().collect { _marketplace.value = it } }
        globalJobs += viewModelScope.launch { repo.observeLostFound().collect { _lostFound.value = it } }
        globalJobs += viewModelScope.launch { repo.observeAllReports().collect { _allReports.value = it } }
        globalJobs += viewModelScope.launch {
            repo.observeAreas().collect { state ->
                if (state is ResourceState.Success && state.data.isNotEmpty()) {
                    val hasPatgram = state.data.any { it.id == PatgramAreaCatalog.defaultPatgramArea.id }
                    _areas.value = if (hasPatgram) state.data else listOf(PatgramAreaCatalog.defaultPatgramArea) + state.data
                }
            }
        }
    }

    fun bindUserListeners(userId: String?) {
        userSpecificJobs.forEach { it.cancel() }
        userSpecificJobs.clear()

        if (userId.isNullOrBlank()) {
            _myPosts.value = ResourceState.Success(emptyList())
            _myMarketplace.value = ResourceState.Success(emptyList())
            _myReports.value = ResourceState.Success(emptyList())
            userSpecificJobs += viewModelScope.launch {
                repo.observeNotifications("").collect { _notifications.value = it }
            }
            return
        }

        userSpecificJobs += viewModelScope.launch { repo.observeMyPosts(userId).collect { _myPosts.value = it } }
        userSpecificJobs += viewModelScope.launch { repo.observeMyMarketplace(userId).collect { _myMarketplace.value = it } }
        userSpecificJobs += viewModelScope.launch { repo.observeMyReports(userId).collect { _myReports.value = it } }
        userSpecificJobs += viewModelScope.launch { repo.observeNotifications(userId).collect { _notifications.value = it } }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { prefs.setThemeMode(mode) }
    }

    fun setSelectedArea(area: SelectedArea) {
        viewModelScope.launch { prefs.setSelectedArea(area) }
    }

    fun createPost(
        user: UserProfile,
        title: String,
        content: String,
        category: String,
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val area = selectedArea.value
            val post = PublicPost(
                authorId = user.uid,
                authorName = user.name.ifBlank { "জনপদ সদস্য" },
                authorPhone = user.phone,
                title = title.trim(),
                content = content.trim(),
                category = category,
                areaId = area.areaId,
                areaName = area.shortLabel(),
                status = "pending",
                rejectionReason = ""
            )
            repo.createPost(post)
                .onSuccess { onResult(true, "আপনার পোস্ট জমা হয়েছে। অ্যাডমিন অনুমোদনের পর এটি প্রকাশিত হবে।") }
                .onFailure { onResult(false, it.message ?: "পোস্ট জমা ব্যর্থ হয়েছে।") }
        }
    }

    fun deletePost(postId: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            repo.deleteOwnPost(postId)
                .onSuccess { onResult(true, "পোস্ট মুছে ফেলা হয়েছে।") }
                .onFailure { onResult(false, it.message ?: "মুছে ফেলা যায়নি।") }
        }
    }

    fun registerOrUpdateDonor(
        user: UserProfile,
        bloodGroup: String,
        phone: String,
        consentToShowPhone: Boolean,
        union: String,
        village: String,
        isAvailable: Boolean,
        lastDonationDate: String,
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val area = selectedArea.value
            val donor = BloodDonor(
                id = user.uid,
                userId = user.uid,
                name = user.name.ifBlank { "রক্তদাতা" },
                bloodGroup = bloodGroup,
                phone = if (consentToShowPhone) phone.trim() else "",
                consentToShowPhone = consentToShowPhone,
                district = area.district,
                upazila = area.upazila,
                union = union.trim(),
                village = village.trim(),
                areaId = area.areaId,
                isAvailable = isAvailable,
                lastDonationDate = lastDonationDate.trim()
            )
            repo.saveBloodDonor(donor)
                .onSuccess { onResult(true, "রক্তদাতা তথ্য সফলভাবে সংরক্ষিত হয়েছে।") }
                .onFailure { onResult(false, it.message ?: "সংরক্ষণ করা যায়নি।") }
        }
    }

    fun createMarketplaceItem(
        user: UserProfile,
        title: String,
        description: String,
        price: Long,
        category: String,
        condition: String,
        location: String,
        sellerPhone: String,
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val area = selectedArea.value
            val item = MarketplaceItem(
                sellerId = user.uid,
                sellerName = user.name.ifBlank { "বিক্রেতা" },
                title = title.trim(),
                description = description.trim(),
                price = price,
                category = category,
                condition = condition,
                location = location.trim().ifBlank { area.shortLabel() },
                areaId = area.areaId,
                sellerPhone = sellerPhone.trim(),
                status = "pending"
            )
            repo.createMarketplaceItem(item)
                .onSuccess { onResult(true, "আপনার বিজ্ঞাপন জমা হয়েছে। অ্যাডমিন অনুমোদনের পর দেখা যাবে।") }
                .onFailure { onResult(false, it.message ?: "বিজ্ঞাপন জমা ব্যর্থ হয়েছে।") }
        }
    }

    fun createLostFound(
        user: UserProfile,
        type: String,
        title: String,
        description: String,
        location: String,
        dateText: String,
        contactPhone: String,
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val area = selectedArea.value
            val entry = LostFoundItem(
                reporterId = user.uid,
                reporterName = user.name.ifBlank { "ব্যবহারকারী" },
                type = type,
                title = title.trim(),
                description = description.trim(),
                location = location.trim(),
                areaId = area.areaId,
                dateText = dateText.trim(),
                contactPhone = contactPhone.trim(),
                isResolved = false
            )
            repo.createLostFoundItem(entry)
                .onSuccess { onResult(true, "হারানো/প্রাপ্তি তথ্য সফলভাবে প্রকাশিত হয়েছে।") }
                .onFailure { onResult(false, it.message ?: "জমা দেওয়া যায়নি।") }
        }
    }

    fun createReport(
        user: UserProfile,
        category: String,
        title: String,
        description: String,
        locationDetail: String,
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val area = selectedArea.value
            val report = AreaReport(
                reporterId = user.uid,
                reporterName = user.name.ifBlank { "নাগরিক" },
                category = category,
                title = title.trim(),
                description = description.trim(),
                locationDetail = locationDetail.trim(),
                areaId = area.areaId,
                areaName = area.shortLabel(),
                status = "submitted",
                adminNote = ""
            )
            repo.createReport(report)
                .onSuccess { onResult(true, "আপনার অভিযোগ সফলভাবে জমা হয়েছে।") }
                .onFailure { onResult(false, it.message ?: "অভিযোগ জমা ব্যর্থ হয়েছে।") }
        }
    }

    fun markNotificationRead(id: String) {
        viewModelScope.launch { repo.markNotificationRead(id) }
    }
}
