package com.janapad.user.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.janapad.user.data.model.ResourceState
import com.janapad.user.data.model.ThemeMode
import com.janapad.user.ui.screens.*
import com.janapad.user.ui.viewmodel.AuthViewModel
import com.janapad.user.ui.viewmodel.MainViewModel

private data class BottomNavTab(
    val route: String,
    val label: String,
    val icon: ImageVector
)

@Composable
fun JanapadAppScaffold(
    authViewModel: AuthViewModel,
    mainViewModel: MainViewModel
) {
    val navController = rememberNavController()
    val authState by authViewModel.uiState.collectAsStateWithLifecycle()
    val themeMode by mainViewModel.themeMode.collectAsStateWithLifecycle()
    val selectedArea by mainViewModel.selectedArea.collectAsStateWithLifecycle()
    val areas by mainViewModel.areas.collectAsStateWithLifecycle()

    val newsState by mainViewModel.news.collectAsStateWithLifecycle()
    val noticesState by mainViewModel.notices.collectAsStateWithLifecycle()
    val approvedPostsState by mainViewModel.approvedPosts.collectAsStateWithLifecycle()
    val myPostsState by mainViewModel.myPosts.collectAsStateWithLifecycle()
    val bloodDonorsState by mainViewModel.bloodDonors.collectAsStateWithLifecycle()
    val jobsState by mainViewModel.jobs.collectAsStateWithLifecycle()
    val marketplaceState by mainViewModel.marketplace.collectAsStateWithLifecycle()
    val myMarketplaceState by mainViewModel.myMarketplace.collectAsStateWithLifecycle()
    val lostFoundState by mainViewModel.lostFound.collectAsStateWithLifecycle()
    val allReportsState by mainViewModel.allReports.collectAsStateWithLifecycle()
    val myReportsState by mainViewModel.myReports.collectAsStateWithLifecycle()
    val notificationsState by mainViewModel.notifications.collectAsStateWithLifecycle()

    // Bind user-scoped Firestore listeners whenever logged-in user changes
    LaunchedEffect(authState.userProfile?.uid) {
        mainViewModel.bindUserListeners(authState.userProfile?.uid)
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    // Automatically redirect to Home after login/register succeeds
    LaunchedEffect(authState.isLoggedIn, currentRoute) {
        if (authState.isLoggedIn && (currentRoute == Routes.LOGIN || currentRoute == Routes.REGISTER)) {
            navController.navigate(Routes.HOME) {
                popUpTo(Routes.LOGIN) { inclusive = true }
            }
        }
    }

    val bottomTabs = remember {
        listOf(
            BottomNavTab(Routes.HOME, "হোম", Icons.Rounded.Home),
            BottomNavTab(Routes.NEWS, "সংবাদ", Icons.Rounded.Newspaper),
            BottomNavTab(Routes.POSTS, "পোস্ট", Icons.Rounded.Forum),
            BottomNavTab(Routes.SERVICES, "সেবা", Icons.Rounded.GridView),
            BottomNavTab(Routes.PROFILE, "প্রোফাইল", Icons.Rounded.Person)
        )
    }
    val bottomRoutes = remember { bottomTabs.map { it.route }.toSet() }
    val showBottomBar = currentRoute in bottomRoutes

    fun navigateTo(route: String) {
        if (route in bottomRoutes) {
            navController.navigate(route) {
                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        } else {
            navController.navigate(route) { launchSingleTop = true }
        }
    }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    bottomTabs.forEach { tab ->
                        NavigationBarItem(
                            selected = currentRoute == tab.route,
                            onClick = { navigateTo(tab.route) },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.SPLASH,
            modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding())
        ) {
            composable(Routes.SPLASH) {
                SplashScreen(
                    isCheckingSession = authState.isCheckingSession,
                    isLoggedIn = authState.isLoggedIn,
                    onNavigateToHome = {
                        navController.navigate(Routes.HOME) {
                            popUpTo(Routes.SPLASH) { inclusive = true }
                        }
                    },
                    onNavigateToLogin = {
                        navController.navigate(Routes.LOGIN) {
                            popUpTo(Routes.SPLASH) { inclusive = true }
                        }
                    }
                )
            }

            composable(Routes.LOGIN) {
                LoginScreen(
                    uiState = authState,
                    onLogin = authViewModel::login,
                    onNavigateToRegister = { navController.navigate(Routes.REGISTER) },
                    onNavigateToForgotPassword = { navController.navigate(Routes.FORGOT_PASSWORD) },
                    onClearMessages = authViewModel::clearMessages
                )
            }

            composable(Routes.REGISTER) {
                RegisterScreen(
                    uiState = authState,
                    onRegister = authViewModel::register,
                    onBack = { navController.popBackStack() },
                    onClearMessages = authViewModel::clearMessages
                )
            }

            composable(Routes.FORGOT_PASSWORD) {
                ForgotPasswordScreen(
                    uiState = authState,
                    onSendReset = authViewModel::sendPasswordReset,
                    onBack = { navController.popBackStack() },
                    onClearMessages = authViewModel::clearMessages
                )
            }

            composable(Routes.HOME) {
                HomeScreen(
                    userProfile = authState.userProfile,
                    selectedArea = selectedArea,
                    areaInfos = areas,
                    themeMode = themeMode,
                    newsState = newsState,
                    postsState = approvedPostsState,
                    notificationsState = notificationsState,
                    onToggleTheme = {
                        val next = if (themeMode == ThemeMode.DARK) ThemeMode.LIGHT else ThemeMode.DARK
                        mainViewModel.setThemeMode(next)
                    },
                    onNavigate = { navigateTo(it) },
                    onRetry = { mainViewModel.startPublicListeners() }
                )
            }

            composable(Routes.NEWS) {
                NewsNoticesScreen(
                    newsState = newsState,
                    noticesState = noticesState,
                    onNewsClick = { navController.navigate(Routes.newsDetail(it)) },
                    onRetry = { mainViewModel.startPublicListeners() }
                )
            }

            composable(
                route = Routes.NEWS_DETAIL,
                arguments = listOf(navArgument("newsId") { type = NavType.StringType })
            ) { entry ->
                val newsId = entry.arguments?.getString("newsId").orEmpty()
                val item = (newsState as? ResourceState.Success)?.data?.firstOrNull { it.id == newsId }
                NewsDetailScreen(newsItem = item, onBack = { navController.popBackStack() })
            }

            composable(Routes.POSTS) {
                PostsScreen(
                    approvedPostsState = approvedPostsState,
                    myPostsState = myPostsState,
                    onCreatePostClick = { navController.navigate(Routes.CREATE_POST) },
                    onPostClick = { navController.navigate(Routes.postDetail(it)) },
                    onRetry = { mainViewModel.startPublicListeners() }
                )
            }

            composable(Routes.CREATE_POST) {
                CreatePostScreen(
                    userProfile = authState.userProfile,
                    onSubmit = { title, content, cat, onDone ->
                        val user = authState.userProfile
                        if (user != null) {
                            mainViewModel.createPost(user, title, content, cat, onDone)
                        } else {
                            onDone(false, "আগে লগইন করুন।")
                        }
                    },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(
                route = Routes.POST_DETAIL,
                arguments = listOf(navArgument("postId") { type = NavType.StringType })
            ) { entry ->
                val postId = entry.arguments?.getString("postId").orEmpty()
                val post = (approvedPostsState as? ResourceState.Success)?.data?.firstOrNull { it.id == postId }
                    ?: (myPostsState as? ResourceState.Success)?.data?.firstOrNull { it.id == postId }
                PostDetailScreen(
                    post = post,
                    currentUserId = authState.userProfile?.uid,
                    onDeleteOwnPost = mainViewModel::deletePost,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.SERVICES) {
                ServicesHubScreen(onNavigate = { navigateTo(it) })
            }

            composable(Routes.BLOOD_DONOR) {
                BloodDonorScreen(
                    userProfile = authState.userProfile,
                    selectedArea = selectedArea,
                    donorsState = bloodDonorsState,
                    onSaveDonor = { group, phone, consent, union, village, avail, lastDate, onDone ->
                        val user = authState.userProfile
                        if (user != null) {
                            mainViewModel.registerOrUpdateDonor(
                                user, group, phone, consent, union, village, avail, lastDate, onDone
                            )
                        } else {
                            onDone(false, "আগে লগইন করুন।")
                        }
                    },
                    onRetry = { mainViewModel.startPublicListeners() },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.JOBS) {
                JobsScreen(
                    jobsState = jobsState,
                    onJobClick = { navController.navigate(Routes.jobDetail(it)) },
                    onRetry = { mainViewModel.startPublicListeners() },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(
                route = Routes.JOB_DETAIL,
                arguments = listOf(navArgument("jobId") { type = NavType.StringType })
            ) { entry ->
                val jobId = entry.arguments?.getString("jobId").orEmpty()
                val job = (jobsState as? ResourceState.Success)?.data?.firstOrNull { it.id == jobId }
                JobDetailScreen(job = job, onBack = { navController.popBackStack() })
            }

            composable(Routes.MARKETPLACE) {
                MarketplaceScreen(
                    itemsState = marketplaceState,
                    myItemsState = myMarketplaceState,
                    onItemClick = { navController.navigate(Routes.productDetail(it)) },
                    onCreateClick = { navController.navigate(Routes.CREATE_MARKETPLACE) },
                    onRetry = { mainViewModel.startPublicListeners() },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.CREATE_MARKETPLACE) {
                CreateMarketplaceScreen(
                    userProfile = authState.userProfile,
                    onSubmit = { title, desc, price, cat, cond, loc, phone, onDone ->
                        val user = authState.userProfile
                        if (user != null) {
                            mainViewModel.createMarketplaceItem(user, title, desc, price, cat, cond, loc, phone, onDone)
                        } else {
                            onDone(false, "আগে লগইন করুন।")
                        }
                    },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(
                route = Routes.PRODUCT_DETAIL,
                arguments = listOf(navArgument("itemId") { type = NavType.StringType })
            ) { entry ->
                val itemId = entry.arguments?.getString("itemId").orEmpty()
                val item = (marketplaceState as? ResourceState.Success)?.data?.firstOrNull { it.id == itemId }
                    ?: (myMarketplaceState as? ResourceState.Success)?.data?.firstOrNull { it.id == itemId }
                ProductDetailScreen(item = item, onBack = { navController.popBackStack() })
            }

            composable(Routes.LOST_FOUND) {
                LostFoundScreen(
                    userProfile = authState.userProfile,
                    state = lostFoundState,
                    onCreateEntry = { type, title, desc, loc, dateText, phone, onDone ->
                        val user = authState.userProfile
                        if (user != null) {
                            mainViewModel.createLostFound(user, type, title, desc, loc, dateText, phone, onDone)
                        } else {
                            onDone(false, "আগে লগইন করুন।")
                        }
                    },
                    onRetry = { mainViewModel.startPublicListeners() },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.REPORTS) {
                ReportsScreen(
                    myReportsState = myReportsState,
                    allReportsState = allReportsState,
                    onCreateReportClick = { navController.navigate(Routes.CREATE_REPORT) },
                    onRetry = { mainViewModel.startPublicListeners() },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.CREATE_REPORT) {
                CreateReportScreen(
                    selectedArea = selectedArea,
                    onSubmit = { cat, title, desc, loc, onDone ->
                        val user = authState.userProfile
                        if (user != null) {
                            mainViewModel.createReport(user, cat, title, desc, loc, onDone)
                        } else {
                            onDone(false, "আগে লগইন করুন।")
                        }
                    },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.EMERGENCY) {
                EmergencyScreen(
                    selectedArea = selectedArea,
                    areas = areas,
                    onOpenBloodDonor = { navController.navigate(Routes.BLOOD_DONOR) },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.AREA_SELECTION) {
                AreaSelectionScreen(
                    currentArea = selectedArea,
                    availableAreas = areas,
                    onSaveArea = { area ->
                        mainViewModel.setSelectedArea(area)
                        authViewModel.syncSelectedAreaToProfile(area)
                    },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.NOTIFICATIONS) {
                NotificationsScreen(
                    state = notificationsState,
                    onMarkRead = mainViewModel::markNotificationRead,
                    onRetry = { mainViewModel.bindUserListeners(authState.userProfile?.uid) },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.PROFILE) {
                val myPostsCount = (myPostsState as? ResourceState.Success)?.data?.size ?: 0
                val myReportsCount = (myReportsState as? ResourceState.Success)?.data?.size ?: 0
                ProfileScreen(
                    userProfile = authState.userProfile,
                    selectedArea = selectedArea,
                    themeMode = themeMode,
                    myPostsCount = myPostsCount,
                    myReportsCount = myReportsCount,
                    onThemeModeChange = mainViewModel::setThemeMode,
                    onUpdateProfile = authViewModel::updateProfile,
                    onSendPasswordReset = authViewModel::sendPasswordReset,
                    onNavigate = { navigateTo(it) },
                    onLogout = {
                        authViewModel.logout()
                        navController.navigate(Routes.LOGIN) {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                )
            }
        }
    }
}
