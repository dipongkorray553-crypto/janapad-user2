package com.janapad.user.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.janapad.user.data.model.SelectedArea
import com.janapad.user.data.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "janapad_prefs")

class PreferencesManager(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val AREA_ID = stringPreferencesKey("area_id")
        val DISTRICT = stringPreferencesKey("district")
        val UPAZILA = stringPreferencesKey("upazila")
        val UNION = stringPreferencesKey("union")
        val WARD = stringPreferencesKey("ward")
        val VILLAGE = stringPreferencesKey("village")
    }

    val themeModeFlow: Flow<ThemeMode> = context.dataStore.data.map { prefs ->
        val saved = prefs[Keys.THEME_MODE] ?: ThemeMode.SYSTEM.name
        runCatching { ThemeMode.valueOf(saved) }.getOrDefault(ThemeMode.SYSTEM)
    }

    val selectedAreaFlow: Flow<SelectedArea> = context.dataStore.data.map { prefs ->
        SelectedArea(
            areaId = prefs[Keys.AREA_ID] ?: "patgram_lalmonirhat",
            district = prefs[Keys.DISTRICT] ?: "লালমনিরহাট",
            upazila = prefs[Keys.UPAZILA] ?: "পাটগ্রাম",
            union = prefs[Keys.UNION] ?: "পাটগ্রাম পৌরসভা",
            ward = prefs[Keys.WARD] ?: "ওয়ার্ড নং ১",
            village = prefs[Keys.VILLAGE] ?: ""
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setSelectedArea(area: SelectedArea) {
        context.dataStore.edit {
            it[Keys.AREA_ID] = area.areaId
            it[Keys.DISTRICT] = area.district
            it[Keys.UPAZILA] = area.upazila
            it[Keys.UNION] = area.union
            it[Keys.WARD] = area.ward
            it[Keys.VILLAGE] = area.village
        }
    }
}
