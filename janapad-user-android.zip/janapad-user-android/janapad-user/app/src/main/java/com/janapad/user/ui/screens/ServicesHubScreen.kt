package com.janapad.user.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.janapad.user.ui.navigation.Routes
import com.janapad.user.ui.theme.*

private data class ServiceDirectoryEntry(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val color: Color,
    val route: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServicesHubScreen(onNavigate: (String) -> Unit) {
    val entries = listOf(
        ServiceDirectoryEntry(
            "রক্তদাতা খুঁজুন ও নিবন্ধন",
            "রক্তের গ্রুপ, এলাকা ও প্রস্তুত দাতা খুঁজুন",
            Icons.Rounded.Bloodtype,
            CrimsonEmergency,
            Routes.BLOOD_DONOR
        ),
        ServiceDirectoryEntry(
            "স্থানীয় চাকরি",
            "উপজেলার সর্বশেষ চাকরির বিজ্ঞপ্তি ও যোগাযোগ",
            Icons.Rounded.Work,
            Color(0xFF6A1B9A),
            Routes.JOBS
        ),
        ServiceDirectoryEntry(
            "মার্কেটপ্লেস (কেনাবেচা)",
            "নতুন ও ব্যবহৃত পণ্য কেনাবেচার স্থানীয় বাজার",
            Icons.Rounded.Storefront,
            Color(0xFFD84315),
            Routes.MARKETPLACE
        ),
        ServiceDirectoryEntry(
            "হারানো ও প্রাপ্তি",
            "হারানো জিনিসের রিপোর্ট ও প্রাপ্তি তথ্য",
            Icons.Rounded.FindInPage,
            Color(0xFF00838F),
            Routes.LOST_FOUND
        ),
        ServiceDirectoryEntry(
            "এলাকার সমস্যা রিপোর্ট",
            "রাস্তা, বিদ্যুৎ, পানি, ড্রেনেজ ও জনসেবা অভিযোগ",
            Icons.Rounded.ReportProblem,
            WarningAmber,
            Routes.REPORTS
        ),
        ServiceDirectoryEntry(
            "জরুরি সেবা ও হটলাইন",
            "হাসপাতাল, অ্যাম্বুলেন্স, ফায়ার সার্ভিস, পুলিশ",
            Icons.Rounded.Emergency,
            CrimsonEmergency,
            Routes.EMERGENCY
        ),
        ServiceDirectoryEntry(
            "এলাকা নির্বাচন",
            "জেলা, উপজেলা, ইউনিয়ন, ওয়ার্ড ও গ্রাম পরিবর্তন",
            Icons.Rounded.Map,
            EmeraldPrimary,
            Routes.AREA_SELECTION
        ),
        ServiceDirectoryEntry(
            "নোটিফিকেশন সেন্টার",
            "সংবাদ, জরুরি নোটিশ, পোস্ট ও রিপোর্ট আপডেট",
            Icons.Rounded.Notifications,
            InfoBlue,
            Routes.NOTIFICATIONS
        )
    )

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("নাগরিক সেবাসমূহ", fontWeight = FontWeight.Bold) })
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(entries) { entry ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigate(entry.route) },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(entry.color.copy(alpha = 0.14f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = entry.icon,
                                contentDescription = entry.title,
                                tint = entry.color,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = entry.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = entry.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(
                            Icons.Rounded.ChevronRight,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
