package com.janapad.user.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.janapad.user.data.local.PatgramAreaCatalog
import com.janapad.user.data.model.BloodDonor
import com.janapad.user.data.model.ResourceState
import com.janapad.user.data.model.SelectedArea
import com.janapad.user.data.model.UserProfile
import com.janapad.user.ui.components.*
import com.janapad.user.ui.theme.CrimsonContainerLight
import com.janapad.user.ui.theme.CrimsonEmergency
import com.janapad.user.ui.theme.SuccessGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BloodDonorScreen(
    userProfile: UserProfile?,
    selectedArea: SelectedArea,
    donorsState: ResourceState<List<BloodDonor>>,
    onSaveDonor: (
        bloodGroup: String,
        phone: String,
        consentToShowPhone: Boolean,
        union: String,
        village: String,
        isAvailable: Boolean,
        lastDonationDate: String,
        onDone: (Boolean, String) -> Unit
    ) -> Unit,
    onRetry: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedGroup by remember { mutableStateOf("সব") }
    var onlyAvailable by remember { mutableStateOf(false) }
    var showRegisterDialog by remember { mutableStateOf(false) }

    val existingMine = remember(donorsState, userProfile) {
        (donorsState as? ResourceState.Success)?.data?.firstOrNull { it.userId == userProfile?.uid }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("রক্তদাতা সেবা", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "পেছনে")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showRegisterDialog = true },
                containerColor = CrimsonEmergency,
                contentColor = Color.White,
                icon = { Icon(Icons.Rounded.Bloodtype, contentDescription = null) },
                text = { Text(if (existingMine != null) "আমার তথ্য আপডেট" else "রক্তদাতা হোন") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Spacer(modifier = Modifier.height(8.dp))
            JanapadSearchBar(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                placeholder = "এলাকা, ইউনিয়ন বা নাম দিয়ে খুঁজুন...",
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            CategoryFilterRow(
                categories = listOf("সব") + PatgramAreaCatalog.bloodGroups,
                selected = selectedGroup,
                onSelect = { selectedGroup = it }
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("শুধুমাত্র রক্তদানে প্রস্তুত দাতা দেখান", style = MaterialTheme.typography.bodySmall)
                Switch(checked = onlyAvailable, onCheckedChange = { onlyAvailable = it })
            }

            when (donorsState) {
                is ResourceState.Loading -> LoadingStateView("রক্তদাতা তালিকা লোড হচ্ছে...")
                is ResourceState.Error -> ErrorStateView(donorsState.message, onRetry = onRetry)
                is ResourceState.Success -> {
                    val filtered = donorsState.data.filter { donor ->
                        val matchGroup = selectedGroup == "সব" || donor.bloodGroup == selectedGroup
                        val matchAvail = !onlyAvailable || donor.isAvailable
                        val matchQuery = searchQuery.isBlank() ||
                            donor.name.contains(searchQuery, true) ||
                            donor.union.contains(searchQuery, true) ||
                            donor.village.contains(searchQuery, true) ||
                            donor.upazila.contains(searchQuery, true)
                        matchGroup && matchAvail && matchQuery
                    }

                    if (filtered.isEmpty()) {
                        EmptyStateView(
                            icon = Icons.Rounded.Bloodtype,
                            title = "কোনো রক্তদাতা পাওয়া যায়নি",
                            subtitle = "অন্য রক্তের গ্রুপ নির্বাচন করুন অথবা নিজেই রক্তদাতা হিসেবে নিবন্ধন করুন।",
                            actionLabel = "রক্তদাতা নিবন্ধন",
                            onAction = { showRegisterDialog = true }
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 84.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(filtered, key = { it.id }) { donor ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(52.dp)
                                                .clip(CircleShape)
                                                .background(CrimsonContainerLight),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = donor.bloodGroup,
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = CrimsonEmergency
                                            )
                                        }
                                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Text(
                                                    text = donor.name,
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                StatusBadge(
                                                    text = if (donor.isAvailable) "প্রস্তুত" else "ব্যস্ত",
                                                    containerColor = if (donor.isAvailable) Color(0xFFD8F5E3) else MaterialTheme.colorScheme.surfaceVariant,
                                                    contentColor = if (donor.isAvailable) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Text(
                                                text = donor.locationText(),
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            if (donor.lastDonationDate.isNotBlank()) {
                                                Text(
                                                    text = "সর্বশেষ রক্তদান: ${donor.lastDonationDate}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            if (!donor.consentToShowPhone || donor.phone.isBlank()) {
                                                Text(
                                                    text = "দাতার গোপনীয়তা অনুরোধে নম্বর প্রদর্শিত নয়",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                        if (donor.consentToShowPhone && donor.phone.isNotBlank()) {
                                            FilledTonalIconButton(
                                                onClick = { dialPhone(context, donor.phone) },
                                                colors = IconButtonDefaults.filledTonalIconButtonColors(
                                                    containerColor = CrimsonEmergency,
                                                    contentColor = Color.White
                                                )
                                            ) {
                                                Icon(Icons.Rounded.Call, contentDescription = "কল করুন")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showRegisterDialog) {
        DonorRegistrationDialog(
            existing = existingMine,
            userProfile = userProfile,
            selectedArea = selectedArea,
            onDismiss = { showRegisterDialog = false },
            onSave = { group, phone, consent, union, village, available, lastDate ->
                onSaveDonor(group, phone, consent, union, village, available, lastDate) { ok, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                    if (ok) showRegisterDialog = false
                }
            }
        )
    }
}

@Composable
private fun DonorRegistrationDialog(
    existing: BloodDonor?,
    userProfile: UserProfile?,
    selectedArea: SelectedArea,
    onDismiss: () -> Unit,
    onSave: (String, String, Boolean, String, String, Boolean, String) -> Unit
) {
    val context = LocalContext.current
    var bloodGroup by remember { mutableStateOf(existing?.bloodGroup ?: "O+") }
    var phone by remember { mutableStateOf(existing?.phone?.ifBlank { userProfile?.phone.orEmpty() } ?: userProfile?.phone.orEmpty()) }
    var consentToShowPhone by remember { mutableStateOf(existing?.consentToShowPhone ?: false) }
    var union by remember { mutableStateOf(existing?.union?.ifBlank { selectedArea.union } ?: selectedArea.union) }
    var village by remember { mutableStateOf(existing?.village?.ifBlank { selectedArea.village } ?: selectedArea.village) }
    var isAvailable by remember { mutableStateOf(existing?.isAvailable ?: true) }
    var lastDonation by remember { mutableStateOf(existing?.lastDonationDate ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("রক্তদাতা নিবন্ধন / আপডেট", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("রক্তের গ্রুপ নির্বাচন করুন", style = MaterialTheme.typography.labelLarge)
                CategoryFilterRow(
                    categories = PatgramAreaCatalog.bloodGroups,
                    selected = bloodGroup,
                    onSelect = { bloodGroup = it },
                    modifier = Modifier.padding(horizontal = 0.dp)
                )

                OutlinedTextField(
                    value = union,
                    onValueChange = { union = it },
                    label = { Text("ইউনিয়ন / পৌরসভা") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = village,
                    onValueChange = { village = it },
                    label = { Text("গ্রাম / মহল্লা") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("মোবাইল নম্বর") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = lastDonation,
                    onValueChange = { lastDonation = it },
                    label = { Text("সর্বশেষ রক্তদানের তারিখ (ঐচ্ছিক)") },
                    placeholder = { Text("যেমন: ১০ আগস্ট ২০২৬") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("বর্তমানে রক্তদানে প্রস্তুত", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = isAvailable, onCheckedChange = { isAvailable = it })
                }

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = consentToShowPhone,
                            onCheckedChange = { consentToShowPhone = it }
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "জরুরি প্রয়োজনে আমার মোবাইল নম্বর JANAPAD রক্তদাতা তালিকায় প্রকাশ করার সম্মতি দিচ্ছি।",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (consentToShowPhone && phone.trim().length < 11) {
                        Toast.makeText(context, "সম্মতি দিলে সঠিক মোবাইল নম্বর লিখুন।", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    onSave(bloodGroup, phone, consentToShowPhone, union, village, isAvailable, lastDonation)
                }
            ) { Text("সংরক্ষণ করুন") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বাতিল") }
        }
    )
}
