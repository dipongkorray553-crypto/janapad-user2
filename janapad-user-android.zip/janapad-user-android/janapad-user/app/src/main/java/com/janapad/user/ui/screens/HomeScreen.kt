package com.janapad.user.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.janapad.user.BuildConfig
import com.janapad.user.data.local.PatgramAreaCatalog
import com.janapad.user.data.model.*
import com.janapad.user.ui.components.*
import com.janapad.user.ui.navigation.Routes
import com.janapad.user.ui.theme.*

private data class QuickServiceItem(
    val title: String,
    val icon: ImageVector,
    val color: Color,
    val route: String
)

@Composable
fun HomeScreen(
    userProfile: UserProfile?,
    selectedArea: SelectedArea,
    areaInfos: List<AreaInfo>,
    themeMode: ThemeMode,
    newsState: ResourceState<List<NewsItem>>,
    postsState: ResourceState<List<PublicPost>>,
    notificationsState: ResourceState<List<AppNotification>>,
    onToggleTheme: () -> Unit,
    onNavigate: (String) -> Unit,
    onRetry: () -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }

    val unreadCount = remember(notificationsState) {
        if (notificationsState is ResourceState.Success) {
            notificationsState.data.count { !it.isRead }
        } else 0
    }

    val currentAreaInfo = remember(areaInfos, selectedArea) {
        areaInfos.firstOrNull { it.id == selectedArea.areaId } ?: PatgramAreaCatalog.defaultPatgramArea
    }

    val services = remember {
        listOf(
            QuickServiceItem("সংবাদ ও নোটিশ", Icons.Rounded.Newspaper, EmeraldPrimary, Routes.NEWS),
            QuickServiceItem("জনপদ পোস্ট", Icons.Rounded.Forum, InfoBlue, Routes.POSTS),
            QuickServiceItem("রক্তদাতা", Icons.Rounded.Bloodtype, CrimsonEmergency, Routes.BLOOD_DONOR),
            QuickServiceItem("স্থানীয় চাকরি", Icons.Rounded.Work, Color(0xFF6A1B9A), Routes.JOBS),
            QuickServiceItem("কেনাবেচা", Icons.Rounded.Storefront, Color(0xFFD84315), Routes.MARKETPLACE),
            QuickServiceItem("হারানো ও প্রাপ্তি", Icons.Rounded.FindInPage, Color(0xFF00838F), Routes.LOST_FOUND),
            QuickServiceItem("সমস্যা রিপোর্ট", Icons.Rounded.ReportProblem, WarningAmber, Routes.REPORTS),
            QuickServiceItem("জরুরি সেবা", Icons.Rounded.Emergency, CrimsonEmergency, Routes.EMERGENCY)
        )
    }

    val allNews = (newsState as? ResourceState.Success)?.data.orEmpty()
    val filteredNews = remember(allNews, searchQuery) {
        if (searchQuery.isBlank()) allNews
        else allNews.filter {
            it.title.contains(searchQuery, true) ||
                it.summary.contains(searchQuery, true) ||
                it.category.contains(searchQuery, true)
        }
    }
    val pinnedNews = remember(filteredNews) { filteredNews.filter { it.isPinned } }

    val allPosts = (postsState as? ResourceState.Success)?.data.orEmpty()
    val filteredPosts = remember(allPosts, searchQuery) {
        if (searchQuery.isBlank()) allPosts.take(5)
        else allPosts.filter {
            it.title.contains(searchQuery, true) || it.content.contains(searchQuery, true)
        }.take(5)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Premium Welcome Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(listOf(EmeraldPrimary, EmeraldDark)),
                        shape = RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp)
                    )
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 18.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "স্বাগতম, ${userProfile?.name?.ifBlank { "জনপদ সদস্য" } ?: "জনপদ সদস্য"}",
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                onClick = { onNavigate(Routes.AREA_SELECTION) },
                                color = Color.White.copy(alpha = 0.18f),
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        Icons.Rounded.LocationOn,
                                        contentDescription = "এলাকা",
                                        tint = GoldLight,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = selectedArea.shortLabel(),
                                        style = MaterialTheme.typography.labelMedium,
                                        color = Color.White
                                    )
                                    Icon(
                                        Icons.Rounded.KeyboardArrowDown,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            IconButton(
                                onClick = onToggleTheme,
                                colors = IconButtonDefaults.iconButtonColors(
                                    containerColor = Color.White.copy(alpha = 0.16f),
                                    contentColor = Color.White
                                )
                            ) {
                                Icon(
                                    imageVector = if (themeMode == ThemeMode.DARK) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                                    contentDescription = "থিম পরিবর্তন"
                                )
                            }

                            IconButton(
                                onClick = { onNavigate(Routes.NOTIFICATIONS) },
                                colors = IconButtonDefaults.iconButtonColors(
                                    containerColor = Color.White.copy(alpha = 0.16f),
                                    contentColor = Color.White
                                )
                            ) {
                                BadgedBox(
                                    badge = {
                                        if (unreadCount > 0) {
                                            Badge { Text(unreadCount.coerceAtMost(99).toString()) }
                                        }
                                    }
                                ) {
                                    Icon(Icons.Rounded.Notifications, contentDescription = "নোটিফিকেশন")
                                }
                            }
                        }
                    }

                    JanapadSearchBar(
                        query = searchQuery,
                        onQueryChange = { searchQuery = it },
                        placeholder = "সংবাদ, পোস্ট বা সেবা খুঁজুন..."
                    )
                }
            }
        }

        // 2. Popular Services Grid (2 rows x 4 columns)
        item {
            SectionHeader(
                title = "জনপ্রিয় সেবাসমূহ",
                actionText = "সব সেবা",
                onActionClick = { onNavigate(Routes.SERVICES) }
            )
            Spacer(modifier = Modifier.height(10.dp))
            Column(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                services.chunked(4).forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        rowItems.forEach { item ->
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onNavigate(item.route) },
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                                border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 12.dp, horizontal = 6.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape)
                                            .background(item.color.copy(alpha = 0.13f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = item.icon,
                                            contentDescription = item.title,
                                            tint = item.color,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = item.title,
                                        style = MaterialTheme.typography.labelSmall,
                                        textAlign = TextAlign.Center,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Emergency Quick Strip
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(CrimsonEmergency),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.Emergency, contentDescription = null, tint = Color.White)
                        }
                        Column {
                            Text(
                                text = "জরুরি প্রয়োজন? ৯৯৯ কল করুন",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Text(
                                text = "পুলিশ, ফায়ার সার্ভিস, অ্যাম্বুলেন্স ও জরুরি নম্বর",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.85f)
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilledTonalButton(
                            onClick = { dialPhone(context, "999") },
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = CrimsonEmergency,
                                contentColor = Color.White
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Rounded.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("৯৯৯")
                        }
                    }
                }
            }
        }

        // 4. Important Pinned News
        if (pinnedNews.isNotEmpty()) {
            item {
                SectionHeader(
                    title = "গুরুত্বপূর্ণ সংবাদ",
                    actionText = "সব দেখুন",
                    onActionClick = { onNavigate(Routes.NEWS) }
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(pinnedNews, key = { it.id }) { news ->
                        Card(
                            modifier = Modifier
                                .width(275.dp)
                                .clickable { onNavigate(Routes.newsDetail(news.id)) },
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        Icons.Rounded.PushPin,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    StatusBadge(
                                        text = news.category,
                                        containerColor = MaterialTheme.colorScheme.primary,
                                        contentColor = MaterialTheme.colorScheme.onPrimary
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = news.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = news.summary.ifBlank { news.content },
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. Latest News
        item {
            SectionHeader(
                title = "সর্বশেষ সংবাদ",
                actionText = "সব সংবাদ",
                onActionClick = { onNavigate(Routes.NEWS) }
            )
        }
        when (newsState) {
            is ResourceState.Loading -> item { LoadingStateView("সংবাদ লোড হচ্ছে...") }
            is ResourceState.Error -> item { ErrorStateView(newsState.message, onRetry = onRetry) }
            is ResourceState.Success -> {
                if (filteredNews.isEmpty()) {
                    item {
                        EmptyStateView(
                            icon = Icons.Rounded.Newspaper,
                            title = "এখনো কোনো সংবাদ প্রকাশিত হয়নি",
                            subtitle = "অ্যাডমিন সংবাদ প্রকাশ করলে এখানে সাথে সাথে দেখা যাবে।"
                        )
                    }
                } else {
                    items(filteredNews.take(4), key = { it.id }) { news ->
                        NewsCard(
                            news = news,
                            onClick = { onNavigate(Routes.newsDetail(news.id)) },
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
            }
        }

        // 6. Recent Approved Public Posts
        item {
            SectionHeader(
                title = "সাম্প্রতিক কমিউনিটি পোস্ট",
                actionText = "পোস্ট করুন",
                onActionClick = { onNavigate(Routes.CREATE_POST) }
            )
        }
        when (postsState) {
            is ResourceState.Loading -> item { LoadingStateView("পোস্ট লোড হচ্ছে...") }
            is ResourceState.Error -> item { ErrorStateView(postsState.message, onRetry = onRetry) }
            is ResourceState.Success -> {
                if (filteredPosts.isEmpty()) {
                    item {
                        EmptyStateView(
                            icon = Icons.Rounded.Forum,
                            title = "কোনো অনুমোদিত পোস্ট নেই",
                            subtitle = "প্রথম পোস্টটি আপনিই জমা দিন। অ্যাডমিন অনুমোদনের পর তা সবাই দেখতে পাবে।",
                            actionLabel = "নতুন পোস্ট লিখুন",
                            onAction = { onNavigate(Routes.CREATE_POST) }
                        )
                    }
                } else {
                    items(filteredPosts, key = { it.id }) { post ->
                        PublicPostCard(
                            post = post,
                            showStatus = false,
                            onClick = { onNavigate(Routes.postDetail(post.id)) },
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
            }
        }

        // 7. Area Information Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Rounded.Map, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text(
                                text = "এলাকা পরিচিতি: ${currentAreaInfo.upazila}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        TextButton(onClick = { onNavigate(Routes.AREA_SELECTION) }) {
                            Text("পরিবর্তন")
                        }
                    }
                    Text(
                        text = "জেলা: ${currentAreaInfo.district} • বিভাগ: ${currentAreaInfo.division}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = currentAreaInfo.description.ifBlank {
                            "${currentAreaInfo.upazila} উপজেলা, ${currentAreaInfo.district} — স্থানীয় তথ্য, জরুরি সেবা ও নাগরিক যোগাযোগের ডিজিটাল ঠিকানা।"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (currentAreaInfo.unions.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "ইউনিয়ন/পৌরসভা: ${currentAreaInfo.unions.size}টি",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // 8. Developer Information — EXCLUSIVELY at the very bottom of Home Page
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Developer: DIP",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "JANAPAD v${BuildConfig.VERSION_NAME}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }
    }
}
