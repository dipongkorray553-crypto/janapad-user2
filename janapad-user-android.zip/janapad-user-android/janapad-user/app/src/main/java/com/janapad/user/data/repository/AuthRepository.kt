package com.janapad.user.data.repository

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.janapad.user.data.model.SelectedArea
import com.janapad.user.data.model.UserProfile
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.tasks.await

class AuthRepository(private val context: Context) {

    val isFirebaseReady: Boolean
        get() = FirebaseGuard.isConfigured(context)

    private val auth: FirebaseAuth?
        get() = if (isFirebaseReady) FirebaseAuth.getInstance() else null

    private val db: FirebaseFirestore?
        get() = if (isFirebaseReady) FirebaseFirestore.getInstance() else null

    val currentUser: FirebaseUser?
        get() = auth?.currentUser

    fun observeAuthState(): Flow<FirebaseUser?> {
        val firebaseAuth = auth ?: return flowOf(null)
        return callbackFlow {
            val listener = FirebaseAuth.AuthStateListener { a ->
                trySend(a.currentUser)
            }
            firebaseAuth.addAuthStateListener(listener)
            trySend(firebaseAuth.currentUser)
            awaitClose { firebaseAuth.removeAuthStateListener(listener) }
        }
    }

    suspend fun login(email: String, password: String): Result<UserProfile> {
        val firebaseAuth = auth ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            val res = firebaseAuth.signInWithEmailAndPassword(email.trim(), password).await()
            val uid = res.user?.uid ?: return Result.failure(Exception("লগইন সম্পন্ন হয়নি।"))
            val profile = fetchUserProfile(uid).getOrElse {
                UserProfile(uid = uid, email = email.trim(), name = res.user?.displayName ?: "জনপদ ব্যবহারকারী")
            }
            Result.success(profile)
        } catch (e: Exception) {
            Result.failure(Exception(mapAuthError(e)))
        }
    }

    suspend fun register(
        name: String,
        phone: String,
        email: String,
        password: String,
        selectedArea: SelectedArea
    ): Result<UserProfile> {
        val firebaseAuth = auth ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            val res = firebaseAuth.createUserWithEmailAndPassword(email.trim(), password).await()
            val uid = res.user?.uid ?: return Result.failure(Exception("অ্যাকাউন্ট তৈরি করা যায়নি।"))
            val now = System.currentTimeMillis()
            val profile = UserProfile(
                uid = uid,
                name = name.trim(),
                email = email.trim(),
                phone = phone.trim(),
                role = "user",
                district = selectedArea.district,
                upazila = selectedArea.upazila,
                union = selectedArea.union,
                ward = selectedArea.ward,
                village = selectedArea.village,
                areaId = selectedArea.areaId,
                createdAt = now,
                updatedAt = now
            )
            firestore.collection("users").document(uid).set(profile).await()
            Result.success(profile)
        } catch (e: Exception) {
            Result.failure(Exception(mapAuthError(e)))
        }
    }

    suspend fun sendPasswordReset(email: String): Result<Unit> {
        val firebaseAuth = auth ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            firebaseAuth.sendPasswordResetEmail(email.trim()).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(Exception(mapAuthError(e)))
        }
    }

    suspend fun fetchUserProfile(uid: String): Result<UserProfile> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            val snap = firestore.collection("users").document(uid).get().await()
            val profile = snap.toObject(UserProfile::class.java)
            if (profile != null) {
                Result.success(profile)
            } else {
                val fbUser = auth?.currentUser
                val fallback = UserProfile(
                    uid = uid,
                    name = fbUser?.displayName?.ifBlank { "জনপদ ব্যবহারকারী" } ?: "জনপদ ব্যবহারকারী",
                    email = fbUser?.email ?: "",
                    role = "user"
                )
                firestore.collection("users").document(uid).set(fallback).await()
                Result.success(fallback)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateUserProfile(profile: UserProfile): Result<UserProfile> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            val updated = profile.copy(
                role = profile.role.ifBlank { "user" },
                updatedAt = System.currentTimeMillis()
            )
            firestore.collection("users").document(updated.uid).set(updated).await()
            Result.success(updated)
        } catch (e: Exception) {
            Result.failure(Exception("প্রোফাইল আপডেট ব্যর্থ হয়েছে: ${e.localizedMessage ?: "অজানা ত্রুটি"}"))
        }
    }

    fun logout() {
        auth?.signOut()
    }

    private fun mapAuthError(e: Exception): String {
        val msg = e.localizedMessage.orEmpty()
        return when {
            msg.contains("password is invalid", ignoreCase = true) ||
                msg.contains("INVALID_LOGIN_CREDENTIALS", ignoreCase = true) ||
                msg.contains("credential is incorrect", ignoreCase = true) ->
                "ইমেইল অথবা পাসওয়ার্ড সঠিক নয়।"
            msg.contains("no user record", ignoreCase = true) ->
                "এই ইমেইলে কোনো অ্যাকাউন্ট পাওয়া যায়নি।"
            msg.contains("already in use", ignoreCase = true) ->
                "এই ইমেইল দিয়ে ইতিমধ্যে অ্যাকাউন্ট তৈরি করা আছে।"
            msg.contains("badly formatted", ignoreCase = true) ->
                "সঠিক ইমেইল ঠিকানা লিখুন।"
            msg.contains("at least 6 characters", ignoreCase = true) ->
                "পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।"
            msg.contains("network error", ignoreCase = true) ->
                "ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।"
            else -> msg.ifBlank { "অনুরোধটি সম্পন্ন করা যায়নি।" }
        }
    }
}
