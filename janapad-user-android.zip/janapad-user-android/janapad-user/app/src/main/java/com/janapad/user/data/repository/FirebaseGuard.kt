package com.janapad.user.data.repository

import android.content.Context
import com.google.firebase.FirebaseApp

object FirebaseGuard {
    fun isConfigured(context: Context): Boolean {
        return try {
            FirebaseApp.getApps(context).isNotEmpty()
        } catch (_: Exception) {
            false
        }
    }

    const val NOT_CONFIGURED_MESSAGE =
        "Firebase এখনো যুক্ত করা হয়নি। লাইভ ডেটা ব্যবহার করতে আপনার Firebase Console থেকে google-services.json ডাউনলোড করে app/ ফোল্ডারে যুক্ত করুন অথবা GitHub Secret সেট করুন।"
}
