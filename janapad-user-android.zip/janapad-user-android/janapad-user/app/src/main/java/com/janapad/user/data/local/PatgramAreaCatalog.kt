package com.janapad.user.data.local

import com.janapad.user.data.model.AreaInfo
import com.janapad.user.data.model.EmergencyContact

/**
 * Real administrative geographic structure for Patgram Upazila, Lalmonirhat, Bangladesh
 * and verified Bangladesh national emergency helplines.
 * Additional districts/upazilas are loaded dynamically from Firestore 'areas' collection.
 */
object PatgramAreaCatalog {

    val defaultPatgramArea = AreaInfo(
        id = "patgram_lalmonirhat",
        division = "রংপুর",
        district = "লালমনিরহাট",
        upazila = "পাটগ্রাম",
        isActive = true,
        description = "পাটগ্রাম উপজেলা বাংলাদেশের রংপুর বিভাগের লালমনিরহাট জেলার একটি সীমান্তবর্তী উপজেলা। এখানে বুড়িমারী স্থলবন্দর ও ঐতিহাসিক দহগ্রাম-আঙ্গরপোতা অবস্থিত।",
        unions = listOf(
            "পাটগ্রাম পৌরসভা",
            "পাটগ্রাম ইউনিয়ন",
            "বুড়িমারী ইউনিয়ন",
            "বাউরা ইউনিয়ন",
            "কুচলিবাড়ী ইউনিয়ন",
            "জগতবেড় ইউনিয়ন",
            "শ্রীরামপুর ইউনিয়ন",
            "দহগ্রাম ইউনিয়ন",
            "জোংড়া ইউনিয়ন"
        ),
        emergencyContacts = emptyList()
    )

    val wards = (1..9).map { "ওয়ার্ড নং $it" }

    val bloodGroups = listOf("A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-")

    val newsCategories = listOf("সব", "জরুরি", "উপজেলা", "শিক্ষা", "কৃষি", "উন্নয়ন", "খেলাধুলা")

    val postCategories = listOf("সব", "সাধারণ", "জনসচেতনতা", "শিক্ষা", "কৃষি", "সাহায্য", "ইভেন্ট", "মতামত")

    val jobCategories = listOf("সব", "শিক্ষা", "অফিস", "ব্যবসা ও সেলস", "আইটি ও ডিজিটাল", "স্বাস্থ্য", "অন্যান্য")

    val marketplaceCategories = listOf("সব", "মোবাইল", "ইলেকট্রনিক্স", "যানবাহন", "কৃষি পণ্য", "আসবাবপত্র", "বই", "অন্যান্য")

    val reportCategories = listOf(
        "road" to "রাস্তাঘাট সমস্যা",
        "electricity" to "বিদ্যুৎ সমস্যা",
        "water" to "পানি সরবরাহ",
        "drainage" to "ড্রেনেজ ও জলাবদ্ধতা",
        "public_service" to "জনসেবা অভিযোগ"
    )

    val emergencyCategories = listOf(
        "সব",
        "হাসপাতাল",
        "অ্যাম্বুলেন্স",
        "ফায়ার সার্ভিস",
        "পুলিশ",
        "জরুরি রক্ত",
        "গুরুত্বপূর্ণ নম্বর"
    )

    // Official Government of Bangladesh National Helplines (always accurate across every Upazila)
    val nationalHelplines = listOf(
        EmergencyContact(
            id = "bd_999",
            category = "পুলিশ",
            name = "জাতীয় জরুরি সেবা (পুলিশ, ফায়ার ও অ্যাম্বুলেন্স)",
            phone = "999",
            address = "জাতীয় হেল্পলাইন — ২৪ ঘণ্টা টোল-ফ্রি",
            isVerified = true
        ),
        EmergencyContact(
            id = "bd_16263",
            category = "হাসপাতাল",
            name = "স্বাস্থ্য বাতায়ন (সরকারি চিকিৎসা পরামর্শ)",
            phone = "16263",
            address = "স্বাস্থ্য অধিদপ্তর — ২৪ ঘণ্টা",
            isVerified = true
        ),
        EmergencyContact(
            id = "bd_16163",
            category = "ফায়ার সার্ভিস",
            name = "ফায়ার সার্ভিস ও সিভিল ডিফেন্স হটলাইন",
            phone = "16163",
            address = "জাতীয় হেল্পলাইন — ২৪ ঘণ্টা",
            isVerified = true
        ),
        EmergencyContact(
            id = "bd_999_amb",
            category = "অ্যাম্বুলেন্স",
            name = "জরুরি অ্যাম্বুলেন্স সহায়তা (৯৯৯)",
            phone = "999",
            address = "জাতীয় জরুরি সেবা — ২৪ ঘণ্টা",
            isVerified = true
        ),
        EmergencyContact(
            id = "bd_333",
            category = "গুরুত্বপূর্ণ নম্বর",
            name = "জাতীয় তথ্য ও সরকারি সেবা কেন্দ্র",
            phone = "333",
            address = "এটুআই / বাংলাদেশ সরকার",
            isVerified = true
        ),
        EmergencyContact(
            id = "bd_109",
            category = "গুরুত্বপূর্ণ নম্বর",
            name = "নারী ও শিশু নির্যাতন প্রতিরোধ হেল্পলাইন",
            phone = "109",
            address = "মহিলা ও শিশু বিষয়ক মন্ত্রণালয় — ২৪ ঘণ্টা",
            isVerified = true
        )
    )

    fun reportCategoryLabel(code: String): String {
        return reportCategories.firstOrNull { it.first == code }?.second ?: "জনসেবা অভিযোগ"
    }

    fun reportStatusLabel(status: String): String = when (status) {
        "submitted" -> "জমা হয়েছে"
        "in_review" -> "পর্যালোচনাধীন"
        "in_progress" -> "কাজ চলছে"
        "resolved" -> "সমাধান হয়েছে"
        "rejected" -> "প্রত্যাখ্যাত"
        else -> status
    }

    fun postStatusLabel(status: String): String = when (status) {
        "pending" -> "অনুমোদনের অপেক্ষায়"
        "approved" -> "প্রকাশিত"
        "rejected" -> "বাতিল হয়েছে"
        else -> status
    }
}
