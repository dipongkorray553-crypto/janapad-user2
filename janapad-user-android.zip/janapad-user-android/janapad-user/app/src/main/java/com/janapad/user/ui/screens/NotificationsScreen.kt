package com.janapad.user.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.janapad.user.data.model.AppNotification
import com.janapad.user.data.model.ResourceState
import com.janapad.user.ui.components.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsScreen(
    state: ResourceState<List<AppNotification>>,
    onMarkRead: (String) -> Unit,
    onRetry: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("নোটিফিকেশন", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "পেছনে")
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (state) {
                is ResourceState.Loading -> LoadingStateView("নোটিফিকেশন লোড হচ্ছে...")
                is ResourceState.Error -> ErrorStateView(state.message, onRetry = onRetry)
                is ResourceState.Success -> {
                    if (state.data.isEmpty()) {
                        EmptyStateView(
                            icon = Icons.Rounded.Notifications,
                            title = "কোনো নোটিফিকেশন নেই",
                            subtitle = "নতুন সংবাদ, জরুরি নোটিশ, পোস্ট অনুমোদন বা রিপোর্ট আপডেট এলে এখানে দেখাবে।"
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(state.data, key = { it.id }) { notif ->
                                val typeLabel = when (notif.type) {
                                    "news" -> "নতুন সংবাদ"
                                    "notice" -> "জরুরি নোটিশ"
                                    "post_status" -> "পোস্ট আপডেট"
                                    "report_status" -> "রিপোর্ট আপডেট"
                                    else -> "বিজ্ঞপ্তি"
                                }
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (!notif.isRead && notif.targetUserId != "all") {
                                                onMarkRead(notif.id)
                                            }
                                        },
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (notif.isRead) MaterialTheme.colorScheme.surface
                                        else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                                    ),
                                    border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            StatusBadge(
                                                typeLabel,
                                                MaterialTheme.colorScheme.primaryContainer,
                                                MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                            Text(
                                                text = formatShortDateBn(notif.createdAt),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Text(notif.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text(notif.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
