package com.janapad.user.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.janapad.user.data.local.PatgramAreaCatalog
import com.janapad.user.data.model.NewsItem
import com.janapad.user.data.model.NoticeItem
import com.janapad.user.data.model.ResourceState
import com.janapad.user.ui.components.*
import com.janapad.user.ui.theme.CrimsonContainerLight
import com.janapad.user.ui.theme.CrimsonEmergency

@Composable
fun NewsCard(
    news: NewsItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    StatusBadge(
                        text = news.category,
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    if (news.isPinned) {
                        StatusBadge(
                            text = "পিনকৃত",
                            containerColor = CrimsonContainerLight,
                            contentColor = CrimsonEmergency
                        )
                    }
                }
                Text(
                    text = formatShortDateBn(news.publishedAt),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                text = news.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = news.summary.ifBlank { news.content },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    Icons.Rounded.Person,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "${news.authorName} • ${news.areaName}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewsNoticesScreen(
    newsState: ResourceState<List<NewsItem>>,
    noticesState: ResourceState<List<NoticeItem>>,
    onNewsClick: (String) -> Unit,
    onRetry: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("সব") }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("সংবাদ ও নোটিশ বোর্ড", fontWeight = FontWeight.Bold) })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("সংবাদ") },
                    icon = { Icon(Icons.Rounded.Newspaper, contentDescription = null) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("নোটিশ বোর্ড") },
                    icon = { Icon(Icons.Rounded.Campaign, contentDescription = null) }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            JanapadSearchBar(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                placeholder = if (selectedTab == 0) "সংবাদ খুঁজুন..." else "নোটিশ খুঁজুন...",
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            if (selectedTab == 0) {
                Spacer(modifier = Modifier.height(8.dp))
                CategoryFilterRow(
                    categories = PatgramAreaCatalog.newsCategories,
                    selected = selectedCategory,
                    onSelect = { selectedCategory = it }
                )
                Spacer(modifier = Modifier.height(8.dp))

                when (newsState) {
                    is ResourceState.Loading -> LoadingStateView("সংবাদ লোড হচ্ছে...")
                    is ResourceState.Error -> ErrorStateView(newsState.message, onRetry = onRetry)
                    is ResourceState.Success -> {
                        val filtered = newsState.data.filter { item ->
                            val matchesCat = selectedCategory == "সব" || item.category == selectedCategory
                            val matchesQ = searchQuery.isBlank() ||
                                item.title.contains(searchQuery, true) ||
                                item.content.contains(searchQuery, true)
                            matchesCat && matchesQ
                        }.sortedByDescending { it.isPinned }

                        if (filtered.isEmpty()) {
                            EmptyStateView(
                                icon = Icons.Rounded.Newspaper,
                                title = "কোনো সংবাদ পাওয়া যায়নি",
                                subtitle = "অন্য ক্যাটাগরি নির্বাচন করুন অথবা নতুন সংবাদের জন্য অপেক্ষা করুন।"
                            )
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(filtered, key = { it.id }) { item ->
                                    NewsCard(news = item, onClick = { onNewsClick(item.id) })
                                }
                            }
                        }
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(8.dp))
                when (noticesState) {
                    is ResourceState.Loading -> LoadingStateView("নোটিশ লোড হচ্ছে...")
                    is ResourceState.Error -> ErrorStateView(noticesState.message, onRetry = onRetry)
                    is ResourceState.Success -> {
                        val filtered = noticesState.data.filter { n ->
                            searchQuery.isBlank() ||
                                n.title.contains(searchQuery, true) ||
                                n.content.contains(searchQuery, true) ||
                                n.department.contains(searchQuery, true)
                        }
                        if (filtered.isEmpty()) {
                            EmptyStateView(
                                icon = Icons.Rounded.Campaign,
                                title = "কোনো নোটিশ নেই",
                                subtitle = "গুরুত্বপূর্ণ সরকারি বা স্থানীয় নোটিশ প্রকাশিত হলে এখানে দেখাবে।"
                            )
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(filtered, key = { it.id }) { notice ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = BorderStroke(
                                            1.dp,
                                            if (notice.priority == "high") CrimsonEmergency.copy(alpha = 0.5f)
                                            else MaterialTheme.colorScheme.outline
                                        )
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                StatusBadge(
                                                    text = if (notice.priority == "high") "জরুরি নোটিশ" else notice.department,
                                                    containerColor = if (notice.priority == "high") CrimsonContainerLight
                                                    else MaterialTheme.colorScheme.primaryContainer,
                                                    contentColor = if (notice.priority == "high") CrimsonEmergency
                                                    else MaterialTheme.colorScheme.onPrimaryContainer
                                                )
                                                Text(
                                                    text = formatShortDateBn(notice.createdAt),
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Text(
                                                text = notice.title,
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = notice.content,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            if (notice.validUntil.isNotBlank()) {
                                                Text(
                                                    text = "মেয়াদ: ${notice.validUntil}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewsDetailScreen(
    newsItem: NewsItem?,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("সংবাদ বিস্তারিত") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "পেছনে")
                    }
                },
                actions = {
                    if (newsItem != null) {
                        IconButton(onClick = { shareText(context, newsItem.title, newsItem.content) }) {
                            Icon(Icons.Rounded.Share, contentDescription = "শেয়ার")
                        }
                    }
                }
            )
        }
    ) { padding ->
        if (newsItem == null) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                EmptyStateView(
                    icon = Icons.Rounded.Newspaper,
                    title = "সংবাদটি পাওয়া যায়নি",
                    subtitle = "সংবাদটি সরিয়ে ফেলা হয়েছে অথবা লোড হতে পারেনি।"
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusBadge(
                        text = newsItem.category,
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    if (newsItem.isPinned) {
                        StatusBadge("গুরুত্বপূর্ণ", CrimsonContainerLight, CrimsonEmergency)
                    }
                }
                Text(
                    text = newsItem.title,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${newsItem.authorName} • ${newsItem.areaName} • ${formatTimestampBn(newsItem.publishedAt)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                HorizontalDivider()
                if (newsItem.summary.isNotBlank()) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = newsItem.summary,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
                Text(
                    text = newsItem.content,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
    }
}
