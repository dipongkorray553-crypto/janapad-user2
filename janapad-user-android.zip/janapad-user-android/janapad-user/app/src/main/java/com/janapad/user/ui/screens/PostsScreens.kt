package com.janapad.user.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.janapad.user.data.local.PatgramAreaCatalog
import com.janapad.user.data.model.PublicPost
import com.janapad.user.data.model.ResourceState
import com.janapad.user.data.model.UserProfile
import com.janapad.user.ui.components.*

@Composable
fun PublicPostCard(
    post: PublicPost,
    showStatus: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    StatusBadge(
                        text = post.category,
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    if (showStatus) {
                        PostStatusBadge(post.status)
                    }
                }
                Text(
                    text = formatShortDateBn(post.createdAt),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Text(
                text = post.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = post.content,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )

            if (showStatus && post.status == "rejected" && post.rejectionReason.isNotBlank()) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "বাতিলের কারণ: ${post.rejectionReason}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    Icons.Rounded.Person,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "${post.authorName} • ${post.areaName}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostsScreen(
    approvedPostsState: ResourceState<List<PublicPost>>,
    myPostsState: ResourceState<List<PublicPost>>,
    onCreatePostClick: () -> Unit,
    onPostClick: (String) -> Unit,
    onRetry: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("সব") }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("জনপদ পোস্ট", fontWeight = FontWeight.Bold) })
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onCreatePostClick,
                icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
                text = { Text("নতুন পোস্ট") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("অনুমোদিত ফিড") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("আমার পোস্টসমূহ") }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            JanapadSearchBar(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                placeholder = "পোস্ট খুঁজুন...",
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            CategoryFilterRow(
                categories = PatgramAreaCatalog.postCategories,
                selected = selectedCategory,
                onSelect = { selectedCategory = it }
            )
            Spacer(modifier = Modifier.height(8.dp))

            val activeState = if (selectedTab == 0) approvedPostsState else myPostsState
            when (activeState) {
                is ResourceState.Loading -> LoadingStateView("পোস্ট লোড হচ্ছে...")
                is ResourceState.Error -> ErrorStateView(activeState.message, onRetry = onRetry)
                is ResourceState.Success -> {
                    val filtered = activeState.data.filter { post ->
                        val matchesCat = selectedCategory == "সব" || post.category == selectedCategory
                        val matchesQ = searchQuery.isBlank() ||
                            post.title.contains(searchQuery, true) ||
                            post.content.contains(searchQuery, true)
                        matchesCat && matchesQ
                    }
                    if (filtered.isEmpty()) {
                        EmptyStateView(
                            icon = Icons.Rounded.Forum,
                            title = if (selectedTab == 0) "কোনো প্রকাশিত পোস্ট নেই" else "আপনি এখনো কোনো পোস্ট করেননি",
                            subtitle = "পোস্ট জমা দেওয়ার পর অ্যাডমিন অনুমোদন করলে তা পাবলিক ফিডে প্রকাশিত হবে।",
                            actionLabel = "পোস্ট তৈরি করুন",
                            onAction = onCreatePostClick
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 84.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(filtered, key = { it.id }) { post ->
                                PublicPostCard(
                                    post = post,
                                    showStatus = selectedTab == 1,
                                    onClick = { onPostClick(post.id) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatePostScreen(
    userProfile: UserProfile?,
    onSubmit: (title: String, content: String, category: String, onDone: (Boolean, String) -> Unit) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    val categories = remember { PatgramAreaCatalog.postCategories.filter { it != "সব" } }
    var selectedCategory by remember { mutableStateOf(categories.first()) }
    var isSubmitting by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("নতুন পোস্ট জমা দিন") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "পেছনে")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.VerifiedUser, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(
                        text = "আপনার পোস্ট সরাসরি প্রকাশিত হবে না। অ্যাডমিন যাচাই ও অনুমোদনের পর এটি পাবলিক ফিডে দেখা যাবে।",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            Text("ক্যাটাগরি নির্বাচন করুন", style = MaterialTheme.typography.labelLarge)
            CategoryFilterRow(
                categories = categories,
                selected = selectedCategory,
                onSelect = { selectedCategory = it },
                modifier = Modifier.padding(horizontal = 0.dp)
            )

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("পোস্টের শিরোনাম *") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = content,
                onValueChange = { content = it },
                label = { Text("বিস্তারিত লিখুন *") },
                minLines = 6,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    if (userProfile == null) {
                        Toast.makeText(context, "আগে লগইন করুন।", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    if (title.isBlank() || content.isBlank()) {
                        Toast.makeText(context, "শিরোনাম ও বিস্তারিত উভয়ই লিখুন।", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    isSubmitting = true
                    onSubmit(title, content, selectedCategory) { ok, msg ->
                        isSubmitting = false
                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                        if (ok) onBack()
                    }
                },
                enabled = !isSubmitting,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                if (isSubmitting) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(22.dp)
                    )
                } else {
                    Text("অনুমোদনের জন্য জমা দিন")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostDetailScreen(
    post: PublicPost?,
    currentUserId: String?,
    onDeleteOwnPost: (String, (Boolean, String) -> Unit) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("পোস্ট বিস্তারিত") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "পেছনে")
                    }
                },
                actions = {
                    if (post != null) {
                        IconButton(onClick = { shareText(context, post.title, post.content) }) {
                            Icon(Icons.Rounded.Share, contentDescription = "শেয়ার")
                        }
                        if (post.authorId == currentUserId) {
                            IconButton(onClick = { showDeleteConfirm = true }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "মুছুন")
                            }
                        }
                    }
                }
            )
        }
    ) { padding ->
        if (post == null) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                EmptyStateView(
                    icon = Icons.Rounded.Forum,
                    title = "পোস্টটি পাওয়া যায়নি",
                    subtitle = "পোস্টটি মুছে ফেলা হয়ে থাকতে পারে।"
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusBadge(
                        post.category,
                        MaterialTheme.colorScheme.primaryContainer,
                        MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    PostStatusBadge(post.status)
                }
                Text(
                    text = post.title,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${post.authorName} • ${post.areaName} • ${formatTimestampBn(post.createdAt)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                HorizontalDivider()
                Text(
                    text = post.content,
                    style = MaterialTheme.typography.bodyLarge
                )
                if (post.status == "rejected" && post.rejectionReason.isNotBlank()) {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Text(
                            text = "অ্যাডমিন মন্তব্য (বাতিলের কারণ): ${post.rejectionReason}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
            }
        }
    }

    if (showDeleteConfirm && post != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("পোস্ট মুছে ফেলবেন?") },
            text = { Text("এই পোস্টটি স্থায়ীভাবে মুছে ফেলা হবে।") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteOwnPost(post.id) { ok, msg ->
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            if (ok) onBack()
                        }
                    }
                ) { Text("মুছে ফেলুন", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("বাতিল") }
            }
        )
    }
}
