package com.janapad.user.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Palette — Modern Civic Emerald, Warm Amber Gold, Clean Slate
val EmeraldPrimary = Color(0xFF0B6E4F)
val EmeraldDark = Color(0xFF074B36)
val EmeraldLight = Color(0xFF34A87E)
val EmeraldContainerLight = Color(0xFFD6F5E8)
val EmeraldContainerDark = Color(0xFF0D3D2D)

val GoldAccent = Color(0xFFD99100)
val GoldLight = Color(0xFFF2B705)
val GoldContainerLight = Color(0xFFFFF1CC)
val GoldContainerDark = Color(0xFF423000)

val CrimsonEmergency = Color(0xFFC62828)
val CrimsonContainerLight = Color(0xFFFFEBEE)
val CrimsonContainerDark = Color(0xFF4A1215)

val InfoBlue = Color(0xFF1565C0)
val SuccessGreen = Color(0xFF1B873F)
val WarningAmber = Color(0xFFE67E22)

// Light Surface Hierarchy
val LightBackground = Color(0xFFF6F8F7)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEBF1EE)
val LightOnSurface = Color(0xFF121C18)
val LightOnSurfaceVariant = Color(0xFF4E5D57)
val LightOutline = Color(0xFFD4DFDA)

// Dark Surface Hierarchy
val DarkBackground = Color(0xFF0E1412)
val DarkSurface = Color(0xFF161F1C)
val DarkSurfaceVariant = Color(0xFF1F2C27)
val DarkOnSurface = Color(0xFFEAF2EE)
val DarkOnSurfaceVariant = Color(0xFFA7B8B0)
val DarkOutline = Color(0xFF2D3E37)
