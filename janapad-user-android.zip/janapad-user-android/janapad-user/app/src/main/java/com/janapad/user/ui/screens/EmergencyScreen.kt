package com.janapad.user.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.janapad.user.data.local.PatgramAreaCatalog
import com.janapad.user.data.model.AreaInfo
import com.janapad.user.data.model.SelectedArea
import com.janapad.user.ui.components.*
import com.janapad.user.ui.theme.CrimsonContainerLight
import com.janapad.user.ui.theme.CrimsonEmergency

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmergencyScreen(
    selectedArea: SelectedArea,
    areas: List<AreaInfo>,
    onOpenBloodDonor: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var selectedCategory by remember { mutableStateOf("সব") }

    val localContacts = remember(areas, selectedArea) {
        areas.firstOrNull { it.id == selectedArea.areaId }?.emergencyContacts.orEmpty()
    }
    val combinedContacts = remember(localContacts) {
        (localContacts + PatgramAreaCatalog.nationalHelplines).distinctBy { "${it.category}_${it.phone}_${it.name}" }
    }

    val filtered = remember(combinedContacts, selectedCategory) {
        if (selectedCategory == "সব") combinedContacts
        else combinedContacts.filter { it.category == selectedCategory }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("জরুরি সেবা (${selectedArea.upazila})", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "পেছনে")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Spacer(modifier = Modifier.height(8.dp))
            CategoryFilterRow(
                categories = PatgramAreaCatalog.emergencyCategories,
                selected = selectedCategory,
                onSelect = { selectedCategory = it }
            )
            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (selectedCategory == "সব" || selectedCategory == "জরুরি রক্ত") {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = CrimsonContainerLight)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "জরুরি রক্তের প্রয়োজন?",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = CrimsonEmergency
                                    )
                                    Text(
                                        text = "${selectedArea.upazila} উপজেলার রক্তদাতা তালিকা দেখুন",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CrimsonEmergency.copy(alpha = 0.85f)
                                    )
                                }
                                Button(
                                    onClick = onOpenBloodDonor,
                                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonEmergency)
                                ) {
                                    Text("রক্তদাতা খুঁজুন")
                                }
                            }
                        }
                    }
                }

                items(filtered, key = { it.id }) { contact ->
                    val icon = when (contact.category) {
                        "হাসপাতাল" -> Icons.Rounded.LocalHospital
                        "অ্যাম্বুলেন্স" -> Icons.Rounded.AirportShuttle
                        "ফায়ার সার্ভিস" -> Icons.Rounded.LocalFireDepartment
                        "পুলিশ" -> Icons.Rounded.LocalPolice
                        else -> Icons.Rounded.PhoneInTalk
                    }
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(CrimsonContainerLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(icon, contentDescription = null, tint = CrimsonEmergency)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                StatusBadge(
                                    contact.category,
                                    MaterialTheme.colorScheme.surfaceVariant,
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(contact.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                if (contact.address.isNotBlank()) {
                                    Text(
                                        contact.address,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = contact.phone,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = CrimsonEmergency,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            FilledTonalIconButton(
                                onClick = { dialPhone(context, contact.phone) },
                                colors = IconButtonDefaults.filledTonalIconButtonColors(
                                    containerColor = CrimsonEmergency,
                                    contentColor = Color.White
                                )
                            ) {
                                Icon(Icons.Rounded.Call, contentDescription = "কল করুন")
                            }
                        }
                    }
                }
            }
        }
    }
}
