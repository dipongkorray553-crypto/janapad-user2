package com.janapad.user.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.janapad.user.data.local.PatgramAreaCatalog
import com.janapad.user.data.model.MarketplaceItem
import com.janapad.user.data.model.ResourceState
import com.janapad.user.data.model.UserProfile
import com.janapad.user.ui.components.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarketplaceScreen(
    itemsState: ResourceState<List<MarketplaceItem>>,
    myItemsState: ResourceState<List<MarketplaceItem>>,
    onItemClick: (String) -> Unit,
    onCreateClick: () -> Unit,
    onRetry: () -> Unit,
    onBack: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("সব") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("স্থানীয় মার্কেটপ্লেস", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "পেছনে")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onCreateClick,
                icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
                text = { Text("বিজ্ঞাপন দিন") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("সব পণ্য") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("আমার বিজ্ঞাপন") })
            }
            Spacer(modifier = Modifier.height(8.dp))
            JanapadSearchBar(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                placeholder = "পণ্যের নাম বা এলাকা খুঁজুন...",
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            CategoryFilterRow(
                categories = PatgramAreaCatalog.marketplaceCategories,
                selected = selectedCategory,
                onSelect = { selectedCategory = it }
            )
            Spacer(modifier = Modifier.height(8.dp))

            val state = if (selectedTab == 0) itemsState else myItemsState
            when (state) {
                is ResourceState.Loading -> LoadingStateView("পণ্য তালিকা লোড হচ্ছে...")
                is ResourceState.Error -> ErrorStateView(state.message, onRetry = onRetry)
                is ResourceState.Success -> {
                    val filtered = state.data.filter { item ->
                        val matchCat = selectedCategory == "সব" || item.category == selectedCategory
                        val matchQ = searchQuery.isBlank() ||
                            item.title.contains(searchQuery, true) ||
                            item.description.contains(searchQuery, true) ||
                            item.location.contains(searchQuery, true)
                        matchCat && matchQ
                    }
                    if (filtered.isEmpty()) {
                        EmptyStateView(
                            icon = Icons.Rounded.Storefront,
                            title = "কোনো পণ্য পাওয়া যায়নি",
                            subtitle = "কেনাবেচার জন্য আপনার প্রথম বিজ্ঞাপন পোস্ট করুন।",
                            actionLabel = "বিজ্ঞাপন দিন",
                            onAction = onCreateClick
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 84.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(filtered, key = { it.id }) { item ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onItemClick(item.id) },
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                StatusBadge(
                                                    item.category,
                                                    MaterialTheme.colorScheme.primaryContainer,
                                                    MaterialTheme.colorScheme.onPrimaryContainer
                                                )
                                                StatusBadge(
                                                    item.condition,
                                                    MaterialTheme.colorScheme.surfaceVariant,
                                                    MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                if (selectedTab == 1) PostStatusBadge(item.status)
                                            }
                                            Text(
                                                text = "৳ ${item.price}",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        Text(
                                            text = item.title,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${item.sellerName} • ${item.location}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateMarketplaceScreen(
    userProfile: UserProfile?,
    onSubmit: (String, String, Long, String, String, String, String, (Boolean, String) -> Unit) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val categories = remember { PatgramAreaCatalog.marketplaceCategories.filter { it != "সব" } }
    var category by remember { mutableStateOf(categories.first()) }
    var condition by remember { mutableStateOf("ব্যবহৃত") }
    var title by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("") }
    var location by remember { mutableStateOf(userProfile?.upazila ?: "পাটগ্রাম") }
    var phone by remember { mutableStateOf(userProfile?.phone ?: "") }
    var description by remember { mutableStateOf("") }
    var isSaving by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("নতুন পণ্য বিজ্ঞাপন") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "পেছনে")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("ক্যাটাগরি", style = MaterialTheme.typography.labelLarge)
            CategoryFilterRow(categories, category, { category = it }, modifier = Modifier.padding(0.dp))

            Text("পণ্যের অবস্থা", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("নতুন", "ব্যবহৃত").forEach { cond ->
                    FilterChip(
                        selected = condition == cond,
                        onClick = { condition = cond },
                        label = { Text(cond) }
                    )
                }
            }

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("পণ্যের নাম *") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = priceText,
                onValueChange = { priceText = it.filter { ch -> ch.isDigit() } },
                label = { Text("মূল্য (টাকা) *") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = location,
                onValueChange = { location = it },
                label = { Text("অবস্থান / বাজার *") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("যোগাযোগের মোবাইল নম্বর *") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("বিস্তারিত বিবরণ *") },
                minLines = 4,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    val price = priceText.toLongOrNull() ?: 0L
                    if (title.isBlank() || price <= 0L || phone.trim().length < 11 || description.isBlank()) {
                        Toast.makeText(context, "সব প্রয়োজনীয় তথ্য সঠিকভাবে পূরণ করুন।", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    isSaving = true
                    onSubmit(title, description, price, category, condition, location, phone) { ok, msg ->
                        isSaving = false
                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                        if (ok) onBack()
                    }
                },
                enabled = !isSaving,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                if (isSaving) CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(22.dp))
                else Text("বিজ্ঞাপন জমা দিন")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductDetailScreen(
    item: MarketplaceItem?,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("পণ্যের বিস্তারিত") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "পেছনে")
                    }
                }
            )
        }
    ) { padding ->
        if (item == null) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                EmptyStateView(Icons.Rounded.Storefront, "পণ্যটি পাওয়া যায়নি", "বিজ্ঞাপনটি সরিয়ে ফেলা হয়েছে।")
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusBadge(item.category, MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
                    StatusBadge(item.condition, MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(item.title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(
                    text = "৳ ${item.price}",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
                Text("বিক্রেতা: ${item.sellerName} • ${item.location}", style = MaterialTheme.typography.bodyMedium)
                Text("পোস্টের সময়: ${formatTimestampBn(item.createdAt)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                HorizontalDivider()
                Text("বিবরণ", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(item.description, style = MaterialTheme.typography.bodyLarge)
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = { dialPhone(context, item.sellerPhone) },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(50.dp)
                ) {
                    Icon(Icons.Rounded.Call, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("বিক্রেতাকে কল করুন (${item.sellerPhone})")
                }
            }
        }
    }
}
