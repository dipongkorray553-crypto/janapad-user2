package com.janapad.user.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.janapad.user.data.local.PatgramAreaCatalog
import com.janapad.user.data.model.AreaInfo
import com.janapad.user.data.model.SelectedArea

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AreaSelectionScreen(
    currentArea: SelectedArea,
    availableAreas: List<AreaInfo>,
    onSaveArea: (SelectedArea) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val areas = remember(availableAreas) {
        if (availableAreas.isEmpty()) listOf(PatgramAreaCatalog.defaultPatgramArea) else availableAreas
    }

    val districts = remember(areas) { areas.map { it.district }.distinct() }
    var selectedDistrict by remember { mutableStateOf(currentArea.district.ifBlank { districts.first() }) }

    val upazilasForDistrict = remember(areas, selectedDistrict) {
        areas.filter { it.district == selectedDistrict }
    }
    var selectedAreaInfo by remember(upazilasForDistrict) {
        mutableStateOf(
            upazilasForDistrict.firstOrNull { it.upazila == currentArea.upazila }
                ?: upazilasForDistrict.firstOrNull()
                ?: PatgramAreaCatalog.defaultPatgramArea
        )
    }

    val unions = remember(selectedAreaInfo) {
        selectedAreaInfo.unions.ifEmpty { PatgramAreaCatalog.defaultPatgramArea.unions }
    }
    var selectedUnion by remember(unions) {
        mutableStateOf(if (currentArea.union in unions) currentArea.union else unions.first())
    }
    var selectedWard by remember { mutableStateOf(currentArea.ward.ifBlank { PatgramAreaCatalog.wards.first() }) }
    var village by remember { mutableStateOf(currentArea.village) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("এলাকা নির্বাচন করুন", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "পেছনে")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Rounded.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(
                        text = "বর্তমানে পাটগ্রাম উপজেলা (লালমনিরহাট) সক্রিয় রয়েছে। ভবিষ্যতে Firestore-এ নতুন উপজেলা যুক্ত হলে এখানে স্বয়ংক্রিয়ভাবে দেখাবে।",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            // 1. District
            Text("১. জেলা নির্বাচন করুন", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                districts.forEach { dist ->
                    FilterChip(
                        selected = selectedDistrict == dist,
                        onClick = { selectedDistrict = dist },
                        label = { Text(dist) }
                    )
                }
            }

            // 2. Upazila
            Text("২. উপজেলা নির্বাচন করুন", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                upazilasForDistrict.forEach { info ->
                    FilterChip(
                        selected = selectedAreaInfo.id == info.id,
                        onClick = { selectedAreaInfo = info },
                        label = { Text(info.upazila) }
                    )
                }
            }

            // 3. Union
            Text("৩. ইউনিয়ন / পৌরসভা নির্বাচন করুন", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                unions.chunked(2).forEach { pair ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        pair.forEach { unionName ->
                            FilterChip(
                                selected = selectedUnion == unionName,
                                onClick = { selectedUnion = unionName },
                                label = { Text(unionName, maxLines = 1) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (pair.size == 1) Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }

            // 4. Ward
            Text("৪. ওয়ার্ড নির্বাচন করুন", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                PatgramAreaCatalog.wards.chunked(3).forEach { rowWards ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowWards.forEach { wardName ->
                            FilterChip(
                                selected = selectedWard == wardName,
                                onClick = { selectedWard = wardName },
                                label = { Text(wardName) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // 5. Village
            Text("৫. গ্রাম / মহল্লা", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = village,
                onValueChange = { village = it },
                label = { Text("গ্রামের নাম লিখুন (ঐচ্ছিক)") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    val chosen = SelectedArea(
                        areaId = selectedAreaInfo.id,
                        district = selectedAreaInfo.district,
                        upazila = selectedAreaInfo.upazila,
                        union = selectedUnion,
                        ward = selectedWard,
                        village = village.trim()
                    )
                    onSaveArea(chosen)
                    Toast.makeText(context, "এলাকা সংরক্ষিত হয়েছে: ${chosen.shortLabel()}", Toast.LENGTH_SHORT).show()
                    onBack()
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Icon(Icons.Rounded.CheckCircle, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("এলাকা নিশ্চিত করুন")
            }
        }
    }
}
