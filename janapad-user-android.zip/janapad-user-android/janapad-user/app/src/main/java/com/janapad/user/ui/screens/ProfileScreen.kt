package com.janapad.user.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.janapad.user.data.model.SelectedArea
import com.janapad.user.data.model.ThemeMode
import com.janapad.user.data.model.UserProfile
import com.janapad.user.ui.navigation.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    userProfile: UserProfile?,
    selectedArea: SelectedArea,
    themeMode: ThemeMode,
    myPostsCount: Int,
    myReportsCount: Int,
    onThemeModeChange: (ThemeMode) -> Unit,
    onUpdateProfile: (String, String, String, String, String, String, String, (Boolean, String) -> Unit) -> Unit,
    onSendPasswordReset: (String) -> Unit,
    onNavigate: (String) -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    var showEditDialog by remember { mutableStateOf(false) }
    var showLogoutDialog by remember { mutableStateOf(false) }

    val initial = userProfile?.name?.trim()?.firstOrNull()?.uppercaseChar()?.toString() ?: "J"

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("আমার প্রোফাইল", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { showEditDialog = true }) {
                        Icon(Icons.Rounded.Edit, contentDescription = "প্রোফাইল এডিট")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Profile Header Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = initial,
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = userProfile?.name?.ifBlank { "জনপদ সদস্য" } ?: "জনপদ সদস্য",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = userProfile?.email.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                        )
                        if (!userProfile?.phone.isNullOrBlank()) {
                            Text(
                                text = "ফোন: ${userProfile?.phone}",
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                        Text(
                            text = userProfile?.fullAddress() ?: selectedArea.fullLabel(),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                        )
                    }
                }
            }

            // Activity Counters
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigate(Routes.POSTS) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("$myPostsCount", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text("আমার পোস্ট", style = MaterialTheme.typography.labelMedium)
                    }
                }
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigate(Routes.REPORTS) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("$myReportsCount", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text("আমার রিপোর্ট", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }

            // Quick Actions
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column {
                    ProfileMenuItem(Icons.Rounded.Edit, "প্রোফাইল তথ্য সম্পাদনা") { showEditDialog = true }
                    HorizontalDivider()
                    ProfileMenuItem(Icons.Rounded.Forum, "আমার পোস্টসমূহ") { onNavigate(Routes.POSTS) }
                    HorizontalDivider()
                    ProfileMenuItem(Icons.Rounded.ReportProblem, "আমার রিপোর্টসমূহ") { onNavigate(Routes.REPORTS) }
                    HorizontalDivider()
                    ProfileMenuItem(Icons.Rounded.Bloodtype, "আমার রক্তদাতা তথ্য") { onNavigate(Routes.BLOOD_DONOR) }
                    HorizontalDivider()
                    ProfileMenuItem(Icons.Rounded.Map, "এলাকা পরিবর্তন (${selectedArea.shortLabel()})") { onNavigate(Routes.AREA_SELECTION) }
                }
            }

            // Theme Settings
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("অ্যাপ থিম সেটিংস", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ThemeMode.entries.forEach { mode ->
                            FilterChip(
                                selected = themeMode == mode,
                                onClick = { onThemeModeChange(mode) },
                                label = { Text(mode.labelBn) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Account Security & Logout
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column {
                    ProfileMenuItem(Icons.Rounded.LockReset, "পাসওয়ার্ড পরিবর্তন লিংক পাঠান") {
                        val email = userProfile?.email.orEmpty()
                        if (email.isNotBlank()) {
                            onSendPasswordReset(email)
                            Toast.makeText(context, "পাসওয়ার্ড রিসেট ইমেইল পাঠানো হচ্ছে...", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "ইমেইল পাওয়া যায়নি।", Toast.LENGTH_SHORT).show()
                        }
                    }
                    HorizontalDivider()
                    ProfileMenuItem(
                        icon = Icons.AutoMirrored.Rounded.Logout,
                        title = "লগআউট করুন",
                        tint = MaterialTheme.colorScheme.error
                    ) { showLogoutDialog = true }
                }
            }
        }
    }

    if (showEditDialog && userProfile != null) {
        var name by remember { mutableStateOf(userProfile.name) }
        var phone by remember { mutableStateOf(userProfile.phone) }
        var district by remember { mutableStateOf(userProfile.district) }
        var upazila by remember { mutableStateOf(userProfile.upazila) }
        var union by remember { mutableStateOf(userProfile.union) }
        var ward by remember { mutableStateOf(userProfile.ward) }
        var village by remember { mutableStateOf(userProfile.village) }

        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = { Text("প্রোফাইল আপডেট", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("নাম") }, singleLine = true)
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("মোবাইল নম্বর") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true
                    )
                    OutlinedTextField(value = district, onValueChange = { district = it }, label = { Text("জেলা") }, singleLine = true)
                    OutlinedTextField(value = upazila, onValueChange = { upazila = it }, label = { Text("উপজেলা") }, singleLine = true)
                    OutlinedTextField(value = union, onValueChange = { union = it }, label = { Text("ইউনিয়ন / পৌরসভা") }, singleLine = true)
                    OutlinedTextField(value = ward, onValueChange = { ward = it }, label = { Text("ওয়ার্ড") }, singleLine = true)
                    OutlinedTextField(value = village, onValueChange = { village = it }, label = { Text("গ্রাম / মহল্লা") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateProfile(name, phone, district, upazila, union, ward, village) { ok, msg ->
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            if (ok) showEditDialog = false
                        }
                    }
                ) { Text("সংরক্ষণ") }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) { Text("বাতিল") }
            }
        )
    }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text("লগআউট করবেন?") },
            text = { Text("আপনি কি আপনার JANAPAD অ্যাকাউন্ট থেকে লগআউট করতে চান?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showLogoutDialog = false
                        onLogout()
                    }
                ) { Text("লগআউট", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) { Text("বাতিল") }
            }
        )
    }
}

@Composable
private fun ProfileMenuItem(
    icon: ImageVector,
    title: String,
    tint: Color = MaterialTheme.colorScheme.primary,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(icon, contentDescription = null, tint = tint)
        Text(
            text = title,
            style = MaterialTheme.typography.bodyLarge,
            color = if (tint == MaterialTheme.colorScheme.error) tint else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
