package com.janapad.user.ui.navigation

object Routes {
    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val FORGOT_PASSWORD = "forgot_password"

    // Main Bottom Nav Tabs
    const val HOME = "home"
    const val NEWS = "news"
    const val POSTS = "posts"
    const val SERVICES = "services"
    const val PROFILE = "profile"

    // Feature & Detail Screens
    const val NEWS_DETAIL = "news_detail/{newsId}"
    const val CREATE_POST = "create_post"
    const val POST_DETAIL = "post_detail/{postId}"
    const val BLOOD_DONOR = "blood_donor"
    const val JOBS = "jobs"
    const val JOB_DETAIL = "job_detail/{jobId}"
    const val MARKETPLACE = "marketplace"
    const val CREATE_MARKETPLACE = "create_marketplace"
    const val PRODUCT_DETAIL = "product_detail/{itemId}"
    const val LOST_FOUND = "lost_found"
    const val REPORTS = "reports"
    const val CREATE_REPORT = "create_report"
    const val EMERGENCY = "emergency"
    const val AREA_SELECTION = "area_selection"
    const val NOTIFICATIONS = "notifications"

    fun newsDetail(id: String) = "news_detail/$id"
    fun postDetail(id: String) = "post_detail/$id"
    fun jobDetail(id: String) = "job_detail/$id"
    fun productDetail(id: String) = "product_detail/$id"
}
