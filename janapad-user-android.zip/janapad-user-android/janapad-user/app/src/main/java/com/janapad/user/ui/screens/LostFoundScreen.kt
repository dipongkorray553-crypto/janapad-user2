package com.janapad.user.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.janapad.user.data.model.LostFoundItem
import com.janapad.user.data.model.ResourceState
import com.janapad.user.data.model.UserProfile
import com.janapad.user.ui.components.*
import com.janapad.user.ui.theme.CrimsonContainerLight
import com.janapad.user.ui.theme.CrimsonEmergency
import com.janapad.user.ui.theme.SuccessGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LostFoundScreen(
    userProfile: UserProfile?,
    state: ResourceState<List<LostFoundItem>>,
    onCreateEntry: (String, String, String, String, String, String, (Boolean, String) -> Unit) -> Unit,
    onRetry: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var showCreateDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("হারানো ও প্রাপ্তি", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "পেছনে")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showCreateDialog = true },
                icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
                text = { Text("রিপোর্ট করুন") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("সব") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("হারিয়েছে") })
                Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("পাওয়া গেছে") })
            }
            Spacer(modifier = Modifier.height(8.dp))
            JanapadSearchBar(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                placeholder = "জিনিসের নাম বা স্থান খুঁজুন...",
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))

            when (state) {
                is ResourceState.Loading -> LoadingStateView("তথ্য লোড হচ্ছে...")
                is ResourceState.Error -> ErrorStateView(state.message, onRetry = onRetry)
                is ResourceState.Success -> {
                    val filtered = state.data.filter { item ->
                        val matchTab = when (selectedTab) {
                            1 -> item.type == "lost"
                            2 -> item.type == "found"
                            else -> true
                        }
                        val matchQ = searchQuery.isBlank() ||
                            item.title.contains(searchQuery, true) ||
                            item.description.contains(searchQuery, true) ||
                            item.location.contains(searchQuery, true)
                        matchTab && matchQ
                    }
                    if (filtered.isEmpty()) {
                        EmptyStateView(
                            icon = Icons.Rounded.FindInPage,
                            title = "কোনো তথ্য পাওয়া যায়নি",
                            subtitle = "কিছু হারালে বা কুড়িয়ে পেলে এখানে রিপোর্ট করুন।",
                            actionLabel = "রিপোর্ট জমা দিন",
                            onAction = { showCreateDialog = true }
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 84.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(filtered, key = { it.id }) { item ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            StatusBadge(
                                                text = if (item.type == "lost") "হারানো বিজ্ঞপ্তি" else "পাওয়া গেছে",
                                                containerColor = if (item.type == "lost") CrimsonContainerLight else Color(0xFFD8F5E3),
                                                contentColor = if (item.type == "lost") CrimsonEmergency else SuccessGreen
                                            )
                                            Text(
                                                text = item.dateText.ifBlank { formatShortDateBn(item.createdAt) },
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(item.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "স্থান: ${item.location}",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            if (item.contactPhone.isNotBlank()) {
                                                FilledTonalButton(
                                                    onClick = { dialPhone(context, item.contactPhone) },
                                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                                ) {
                                                    Icon(Icons.Rounded.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("যোগাযোগ")
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        var type by remember { mutableStateOf("lost") }
        var title by remember { mutableStateOf("") }
        var location by remember { mutableStateOf("") }
        var dateText by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf(userProfile?.phone ?: "") }
        var description by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("হারানো / প্রাপ্তি রিপোর্ট", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = type == "lost", onClick = { type = "lost" }, label = { Text("হারিয়েছে") })
                        FilterChip(selected = type == "found", onClick = { type = "found" }, label = { Text("পাওয়া গেছে") })
                    }
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("কী হারিয়েছে / পাওয়া গেছে *") }, singleLine = true)
                    OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("স্থান *") }, singleLine = true)
                    OutlinedTextField(value = dateText, onValueChange = { dateText = it }, label = { Text("তারিখ (যেমন: ২৩ নভেম্বর)") }, singleLine = true)
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("যোগাযোগের নম্বর *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true
                    )
                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("বিস্তারিত বিবরণ *") }, minLines = 3)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (title.isBlank() || location.isBlank() || phone.trim().length < 11 || description.isBlank()) {
                            Toast.makeText(context, "সব প্রয়োজনীয় ঘর পূরণ করুন।", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        onCreateEntry(type, title, description, location, dateText, phone) { ok, msg ->
                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                            if (ok) showCreateDialog = false
                        }
                    }
                ) { Text("জমা দিন") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("বাতিল") }
            }
        )
    }
}
