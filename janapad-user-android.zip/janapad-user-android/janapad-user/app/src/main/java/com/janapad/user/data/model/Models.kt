package com.janapad.user.data.model

import com.google.firebase.firestore.PropertyName

// ---------- UI State Wrapper ----------
sealed interface ResourceState<out T> {
    data object Loading : ResourceState<Nothing>
    data class Success<T>(val data: T) : ResourceState<T>
    data class Error(val message: String) : ResourceState<Nothing>
}

enum class ThemeMode(val labelBn: String) {
    SYSTEM("সিস্টেম"),
    LIGHT("লাইট মোড"),
    DARK("ডার্ক মোড")
}

// ---------- Selected Area Hierarchy ----------
data class SelectedArea(
    val areaId: String = "patgram_lalmonirhat",
    val district: String = "লালমনিরহাট",
    val upazila: String = "পাটগ্রাম",
    val union: String = "পাটগ্রাম পৌরসভা",
    val ward: String = "ওয়ার্ড নং ১",
    val village: String = ""
) {
    fun shortLabel(): String = "$upazila, $district"

    fun fullLabel(): String {
        val parts = listOf(village, ward, union, upazila, district).filter { it.isNotBlank() }
        return parts.joinToString(", ")
    }
}

// ---------- 1. Collection: users ----------
data class UserProfile(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val phone: String = "",
    val role: String = "user",
    val district: String = "লালমনিরহাট",
    val upazila: String = "পাটগ্রাম",
    val union: String = "",
    val ward: String = "",
    val village: String = "",
    val areaId: String = "patgram_lalmonirhat",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun fullAddress(): String {
        val parts = listOf(village, ward, union, upazila, district).filter { it.isNotBlank() }
        return if (parts.isEmpty()) "ঠিকানা যুক্ত করা হয়নি" else parts.joinToString(", ")
    }
}

// ---------- 2. Collection: posts ----------
data class PublicPost(
    val id: String = "",
    val authorId: String = "",
    val authorName: String = "",
    val authorPhone: String = "",
    val title: String = "",
    val content: String = "",
    val category: String = "সাধারণ",
    val areaId: String = "patgram_lalmonirhat",
    val areaName: String = "পাটগ্রাম, লালমনিরহাট",
    val status: String = "pending", // pending | approved | rejected
    val rejectionReason: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

// ---------- 3. Collection: news ----------
data class NewsItem(
    val id: String = "",
    val title: String = "",
    val summary: String = "",
    val content: String = "",
    val category: String = "উপজেলা",
    @get:PropertyName("isPinned")
    @set:PropertyName("isPinned")
    var isPinned: Boolean = false,
    val areaId: String = "patgram_lalmonirhat",
    val areaName: String = "পাটগ্রাম, লালমনিরহাট",
    val authorName: String = "জনপদ ডেস্ক",
    val publishedAt: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis()
)

// ---------- 4. Collection: notices ----------
data class NoticeItem(
    val id: String = "",
    val title: String = "",
    val content: String = "",
    val priority: String = "normal", // high | normal
    val department: String = "উপজেলা প্রশাসন",
    val areaId: String = "patgram_lalmonirhat",
    val areaName: String = "পাটগ্রাম, লালমনিরহাট",
    val validUntil: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// ---------- 5. Collection: blood_donors ----------
data class BloodDonor(
    val id: String = "",
    val userId: String = "",
    val name: String = "",
    val bloodGroup: String = "O+",
    val phone: String = "",
    val consentToShowPhone: Boolean = false,
    val district: String = "লালমনিরহাট",
    val upazila: String = "পাটগ্রাম",
    val union: String = "",
    val village: String = "",
    val areaId: String = "patgram_lalmonirhat",
    @get:PropertyName("isAvailable")
    @set:PropertyName("isAvailable")
    var isAvailable: Boolean = true,
    val lastDonationDate: String = "",
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun locationText(): String {
        val parts = listOf(village, union, upazila).filter { it.isNotBlank() }
        return if (parts.isEmpty()) upazila else parts.joinToString(", ")
    }
}

// ---------- 6. Collection: jobs ----------
data class JobListing(
    val id: String = "",
    val title: String = "",
    val companyName: String = "",
    val category: String = "অন্যান্য",
    val salary: String = "আলোচনা সাপেক্ষে",
    val location: String = "পাটগ্রাম",
    val areaId: String = "patgram_lalmonirhat",
    val description: String = "",
    val requirements: String = "",
    val contactPhone: String = "",
    val contactEmail: String = "",
    val deadline: String = "",
    @get:PropertyName("isActive")
    @set:PropertyName("isActive")
    var isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

// ---------- 7. Collection: marketplace ----------
data class MarketplaceItem(
    val id: String = "",
    val sellerId: String = "",
    val sellerName: String = "",
    val title: String = "",
    val description: String = "",
    val price: Long = 0L,
    val category: String = "অন্যান্য",
    val condition: String = "ব্যবহৃত",
    val location: String = "পাটগ্রাম",
    val areaId: String = "patgram_lalmonirhat",
    val sellerPhone: String = "",
    val status: String = "pending", // pending | approved | rejected
    val createdAt: Long = System.currentTimeMillis()
)

// ---------- 8. Collection: lost_found ----------
data class LostFoundItem(
    val id: String = "",
    val reporterId: String = "",
    val reporterName: String = "",
    val type: String = "lost", // lost | found
    val title: String = "",
    val description: String = "",
    val location: String = "",
    val areaId: String = "patgram_lalmonirhat",
    val dateText: String = "",
    val contactPhone: String = "",
    @get:PropertyName("isResolved")
    @set:PropertyName("isResolved")
    var isResolved: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

// ---------- 9. Collection: reports ----------
data class AreaReport(
    val id: String = "",
    val reporterId: String = "",
    val reporterName: String = "",
    val category: String = "road", // road | electricity | water | drainage | public_service
    val title: String = "",
    val description: String = "",
    val locationDetail: String = "",
    val areaId: String = "patgram_lalmonirhat",
    val areaName: String = "পাটগ্রাম, লালমনিরহাট",
    val status: String = "submitted", // submitted | in_review | in_progress | resolved | rejected
    val adminNote: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

// ---------- 10. Collection: notifications ----------
data class AppNotification(
    val id: String = "",
    val targetUserId: String = "all",
    val areaId: String = "patgram_lalmonirhat",
    val type: String = "news", // news | notice | post_status | report_status
    val title: String = "",
    val message: String = "",
    val referenceId: String = "",
    @get:PropertyName("isRead")
    @set:PropertyName("isRead")
    var isRead: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

// ---------- 11. Collection: areas ----------
data class EmergencyContact(
    val id: String = "",
    val category: String = "গুরুত্বপূর্ণ নম্বর",
    val name: String = "",
    val phone: String = "",
    val address: String = "",
    @get:PropertyName("isVerified")
    @set:PropertyName("isVerified")
    var isVerified: Boolean = true
)

data class AreaInfo(
    val id: String = "patgram_lalmonirhat",
    val division: String = "রংপুর",
    val district: String = "লালমনিরহাট",
    val upazila: String = "পাটগ্রাম",
    @get:PropertyName("isActive")
    @set:PropertyName("isActive")
    var isActive: Boolean = true,
    val description: String = "",
    val unions: List<String> = emptyList(),
    val emergencyContacts: List<EmergencyContact> = emptyList()
)
