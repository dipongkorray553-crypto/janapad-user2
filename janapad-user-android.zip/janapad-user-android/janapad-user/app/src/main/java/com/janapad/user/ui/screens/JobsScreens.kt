package com.janapad.user.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.janapad.user.data.local.PatgramAreaCatalog
import com.janapad.user.data.model.JobListing
import com.janapad.user.data.model.ResourceState
import com.janapad.user.ui.components.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JobsScreen(
    jobsState: ResourceState<List<JobListing>>,
    onJobClick: (String) -> Unit,
    onRetry: () -> Unit,
    onBack: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("সব") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("স্থানীয় চাকরি", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "পেছনে")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Spacer(modifier = Modifier.height(8.dp))
            JanapadSearchBar(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                placeholder = "পদের নাম বা প্রতিষ্ঠানের নাম খুঁজুন...",
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            CategoryFilterRow(
                categories = PatgramAreaCatalog.jobCategories,
                selected = selectedCategory,
                onSelect = { selectedCategory = it }
            )
            Spacer(modifier = Modifier.height(8.dp))

            when (jobsState) {
                is ResourceState.Loading -> LoadingStateView("চাকরির বিজ্ঞপ্তি লোড হচ্ছে...")
                is ResourceState.Error -> ErrorStateView(jobsState.message, onRetry = onRetry)
                is ResourceState.Success -> {
                    val filtered = jobsState.data.filter { job ->
                        val matchCat = selectedCategory == "সব" || job.category == selectedCategory
                        val matchQ = searchQuery.isBlank() ||
                            job.title.contains(searchQuery, true) ||
                            job.companyName.contains(searchQuery, true) ||
                            job.location.contains(searchQuery, true)
                        job.isActive && matchCat && matchQ
                    }
                    if (filtered.isEmpty()) {
                        EmptyStateView(
                            icon = Icons.Rounded.Work,
                            title = "কোনো চাকরির বিজ্ঞপ্তি নেই",
                            subtitle = "স্থানীয় নতুন চাকরির বিজ্ঞপ্তি প্রকাশিত হলে এখানে দেখা যাবে।"
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(filtered, key = { it.id }) { job ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onJobClick(job.id) },
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            StatusBadge(
                                                job.category,
                                                MaterialTheme.colorScheme.primaryContainer,
                                                MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                            if (job.deadline.isNotBlank()) {
                                                Text(
                                                    text = "শেষ তারিখ: ${job.deadline}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.error
                                                )
                                            }
                                        }
                                        Text(
                                            text = job.title,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${job.companyName} • ${job.location}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = "বেতন: ${job.salary}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JobDetailScreen(
    job: JobListing?,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("চাকরির বিস্তারিত") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "পেছনে")
                    }
                }
            )
        }
    ) { padding ->
        if (job == null) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                EmptyStateView(Icons.Rounded.Work, "বিজ্ঞপ্তি পাওয়া যায়নি", "এই চাকরির বিজ্ঞপ্তিটি আর উপলব্ধ নয়।")
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatusBadge(
                    job.category,
                    MaterialTheme.colorScheme.primaryContainer,
                    MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(job.title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(job.companyName, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                Text("অবস্থান: ${job.location}", style = MaterialTheme.typography.bodyMedium)
                Text("বেতন: ${job.salary}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                if (job.deadline.isNotBlank()) {
                    Text("আবেদনের শেষ তারিখ: ${job.deadline}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                }
                HorizontalDivider()
                Text("কাজের বিবরণ", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(job.description, style = MaterialTheme.typography.bodyLarge)
                if (job.requirements.isNotBlank()) {
                    Text("যোগ্যতা ও শর্তাবলি", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(job.requirements, style = MaterialTheme.typography.bodyMedium)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (job.contactPhone.isNotBlank()) {
                        Button(
                            onClick = { dialPhone(context, job.contactPhone) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Rounded.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("কল করুন")
                        }
                    }
                    if (job.contactEmail.isNotBlank()) {
                        OutlinedButton(
                            onClick = { sendEmail(context, job.contactEmail, "আবেদন: ${job.title}") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Rounded.Email, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ইমেইল করুন")
                        }
                    }
                }
            }
        }
    }
}
