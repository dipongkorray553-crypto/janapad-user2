package com.janapad.user.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.janapad.user.data.local.PatgramAreaCatalog
import com.janapad.user.data.model.AreaReport
import com.janapad.user.data.model.ResourceState
import com.janapad.user.data.model.SelectedArea
import com.janapad.user.ui.components.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    myReportsState: ResourceState<List<AreaReport>>,
    allReportsState: ResourceState<List<AreaReport>>,
    onCreateReportClick: () -> Unit,
    onRetry: () -> Unit,
    onBack: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val catCodes = remember { listOf("all") + PatgramAreaCatalog.reportCategories.map { it.first } }
    var selectedCat by remember { mutableStateOf("all") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("এলাকার সমস্যা রিপোর্ট", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "পেছনে")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onCreateReportClick,
                icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
                text = { Text("নতুন রিপোর্ট") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("আমার রিপোর্ট") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("সকল রিপোর্ট") })
            }
            Spacer(modifier = Modifier.height(8.dp))
            CategoryFilterRow(
                categories = catCodes.map { if (it == "all") "সব" else PatgramAreaCatalog.reportCategoryLabel(it) },
                selected = if (selectedCat == "all") "সব" else PatgramAreaCatalog.reportCategoryLabel(selectedCat),
                onSelect = { label ->
                    selectedCat = if (label == "সব") "all"
                    else PatgramAreaCatalog.reportCategories.firstOrNull { it.second == label }?.first ?: "all"
                }
            )
            Spacer(modifier = Modifier.height(8.dp))

            val state = if (selectedTab == 0) myReportsState else allReportsState
            when (state) {
                is ResourceState.Loading -> LoadingStateView("রিপোর্ট লোড হচ্ছে...")
                is ResourceState.Error -> ErrorStateView(state.message, onRetry = onRetry)
                is ResourceState.Success -> {
                    val filtered = state.data.filter { selectedCat == "all" || it.category == selectedCat }
                    if (filtered.isEmpty()) {
                        EmptyStateView(
                            icon = Icons.Rounded.ReportProblem,
                            title = "কোনো রিপোর্ট পাওয়া যায়নি",
                            subtitle = "রাস্তাঘাট, বিদ্যুৎ, পানি, ড্রেনেজ বা জনসেবার সমস্যা জানাতে নতুন রিপোর্ট জমা দিন।",
                            actionLabel = "রিপোর্ট জমা দিন",
                            onAction = onCreateReportClick
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 84.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(filtered, key = { it.id }) { report ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            StatusBadge(
                                                PatgramAreaCatalog.reportCategoryLabel(report.category),
                                                MaterialTheme.colorScheme.primaryContainer,
                                                MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                            ReportStatusBadge(report.status)
                                        }
                                        Text(report.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(report.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(
                                            text = "অবস্থান: ${report.locationDetail.ifBlank { report.areaName }}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = "জমা: ${formatTimestampBn(report.createdAt)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (report.adminNote.isNotBlank()) {
                                            Surface(
                                                color = MaterialTheme.colorScheme.surfaceVariant,
                                                shape = RoundedCornerShape(10.dp)
                                            ) {
                                                Text(
                                                    text = "কর্তৃপক্ষের আপডেট: ${report.adminNote}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    modifier = Modifier.padding(10.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateReportScreen(
    selectedArea: SelectedArea,
    onSubmit: (category: String, title: String, description: String, locationDetail: String, (Boolean, String) -> Unit) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var selectedCategory by remember { mutableStateOf(PatgramAreaCatalog.reportCategories.first().first) }
    var title by remember { mutableStateOf("") }
    var locationDetail by remember { mutableStateOf(selectedArea.fullLabel()) }
    var description by remember { mutableStateOf("") }
    var isSaving by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("সমস্যা রিপোর্ট জমা দিন") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "পেছনে")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("সমস্যার ধরন নির্বাচন করুন", style = MaterialTheme.typography.labelLarge)
            CategoryFilterRow(
                categories = PatgramAreaCatalog.reportCategories.map { it.second },
                selected = PatgramAreaCatalog.reportCategoryLabel(selectedCategory),
                onSelect = { label ->
                    selectedCategory = PatgramAreaCatalog.reportCategories.first { it.second == label }.first
                },
                modifier = Modifier.padding(0.dp)
            )

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("সমস্যার সংক্ষিপ্ত শিরোনাম *") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = locationDetail,
                onValueChange = { locationDetail = it },
                label = { Text("সঠিক অবস্থান (গ্রাম, ওয়ার্ড, ইউনিয়ন) *") },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("সমস্যার বিস্তারিত বিবরণ *") },
                minLines = 5,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    if (title.isBlank() || locationDetail.isBlank() || description.isBlank()) {
                        Toast.makeText(context, "সব প্রয়োজনীয় তথ্য পূরণ করুন।", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    isSaving = true
                    onSubmit(selectedCategory, title, description, locationDetail) { ok, msg ->
                        isSaving = false
                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                        if (ok) onBack()
                    }
                },
                enabled = !isSaving,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                if (isSaving) CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(22.dp))
                else Text("রিপোর্ট জমা দিন")
            }
        }
    }
}
