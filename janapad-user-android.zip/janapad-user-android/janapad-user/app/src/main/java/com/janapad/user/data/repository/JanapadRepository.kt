package com.janapad.user.data.repository

import android.content.Context
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.janapad.user.data.model.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.tasks.await

class JanapadRepository(private val context: Context) {

    val isFirebaseReady: Boolean
        get() = FirebaseGuard.isConfigured(context)

    private val db: FirebaseFirestore?
        get() = if (isFirebaseReady) FirebaseFirestore.getInstance() else null

    private inline fun <reified T : Any> observeCollection(
        collectionName: String,
        crossinline queryBuilder: (FirebaseFirestore) -> com.google.firebase.firestore.Query,
        crossinline mapDoc: (String, T) -> T,
        crossinline sortKey: (T) -> Long
    ): Flow<ResourceState<List<T>>> {
        val firestore = db ?: return flowOf(ResourceState.Error(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return callbackFlow {
            trySend(ResourceState.Loading)
            val registration: ListenerRegistration = queryBuilder(firestore)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        trySend(
                            ResourceState.Error(
                                "তথ্য লোড করতে সমস্যা হয়েছে (${collectionName}): ${error.localizedMessage ?: "নেটওয়ার্ক ত্রুটি"}"
                            )
                        )
                        return@addSnapshotListener
                    }
                    val items = snapshot?.documents?.mapNotNull { doc ->
                        doc.toObject(T::class.java)?.let { mapDoc(doc.id, it) }
                    }?.sortedByDescending { sortKey(it) } ?: emptyList()
                    trySend(ResourceState.Success(items))
                }
            awaitClose { registration.remove() }
        }
    }

    // ---------- 1. NEWS ----------
    fun observeNews(): Flow<ResourceState<List<NewsItem>>> = observeCollection(
        collectionName = "news",
        queryBuilder = { it.collection("news").limit(100) },
        mapDoc = { id, item -> item.copy(id = id) },
        sortKey = { it.publishedAt }
    )

    // ---------- 2. NOTICES ----------
    fun observeNotices(): Flow<ResourceState<List<NoticeItem>>> = observeCollection(
        collectionName = "notices",
        queryBuilder = { it.collection("notices").limit(100) },
        mapDoc = { id, item -> item.copy(id = id) },
        sortKey = { it.createdAt }
    )

    // ---------- 3. POSTS (Approved Feed + My Posts) ----------
    fun observeApprovedPosts(): Flow<ResourceState<List<PublicPost>>> = observeCollection(
        collectionName = "posts",
        queryBuilder = { it.collection("posts").whereEqualTo("status", "approved").limit(100) },
        mapDoc = { id, item -> item.copy(id = id) },
        sortKey = { it.createdAt }
    )

    fun observeMyPosts(userId: String): Flow<ResourceState<List<PublicPost>>> {
        if (userId.isBlank()) return flowOf(ResourceState.Success(emptyList()))
        return observeCollection(
            collectionName = "posts",
            queryBuilder = { it.collection("posts").whereEqualTo("authorId", userId).limit(100) },
            mapDoc = { id, item -> item.copy(id = id) },
            sortKey = { it.createdAt }
        )
    }

    suspend fun createPost(post: PublicPost): Result<String> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            val docRef = firestore.collection("posts").document()
            val now = System.currentTimeMillis()
            // Force pending status client-side; also strictly enforced by Firestore Security Rules
            val safePost = post.copy(
                id = docRef.id,
                status = "pending",
                rejectionReason = "",
                createdAt = now,
                updatedAt = now
            )
            docRef.set(safePost).await()
            Result.success(docRef.id)
        } catch (e: Exception) {
            Result.failure(Exception("পোস্ট জমা দেওয়া যায়নি: ${e.localizedMessage ?: "ত্রুটি"}"))
        }
    }

    suspend fun deleteOwnPost(postId: String): Result<Unit> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            firestore.collection("posts").document(postId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(Exception("পোস্ট মুছে ফেলা যায়নি: ${e.localizedMessage ?: "ত্রুটি"}"))
        }
    }

    // ---------- 4. BLOOD DONORS ----------
    fun observeBloodDonors(): Flow<ResourceState<List<BloodDonor>>> = observeCollection(
        collectionName = "blood_donors",
        queryBuilder = { it.collection("blood_donors").limit(200) },
        mapDoc = { id, item -> item.copy(id = id) },
        sortKey = { it.updatedAt }
    )

    suspend fun saveBloodDonor(donor: BloodDonor): Result<Unit> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            val safe = donor.copy(
                id = donor.userId,
                updatedAt = System.currentTimeMillis()
            )
            firestore.collection("blood_donors").document(donor.userId).set(safe).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(Exception("রক্তদাতা তথ্য সংরক্ষণ করা যায়নি: ${e.localizedMessage ?: "ত্রুটি"}"))
        }
    }

    // ---------- 5. LOCAL JOBS ----------
    fun observeJobs(): Flow<ResourceState<List<JobListing>>> = observeCollection(
        collectionName = "jobs",
        queryBuilder = { it.collection("jobs").limit(100) },
        mapDoc = { id, item -> item.copy(id = id) },
        sortKey = { it.createdAt }
    )

    // ---------- 6. MARKETPLACE ----------
    fun observeApprovedMarketplace(): Flow<ResourceState<List<MarketplaceItem>>> = observeCollection(
        collectionName = "marketplace",
        queryBuilder = { it.collection("marketplace").whereEqualTo("status", "approved").limit(100) },
        mapDoc = { id, item -> item.copy(id = id) },
        sortKey = { it.createdAt }
    )

    fun observeMyMarketplace(userId: String): Flow<ResourceState<List<MarketplaceItem>>> {
        if (userId.isBlank()) return flowOf(ResourceState.Success(emptyList()))
        return observeCollection(
            collectionName = "marketplace",
            queryBuilder = { it.collection("marketplace").whereEqualTo("sellerId", userId).limit(100) },
            mapDoc = { id, item -> item.copy(id = id) },
            sortKey = { it.createdAt }
        )
    }

    suspend fun createMarketplaceItem(item: MarketplaceItem): Result<String> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            val docRef = firestore.collection("marketplace").document()
            val safe = item.copy(
                id = docRef.id,
                status = "pending",
                createdAt = System.currentTimeMillis()
            )
            docRef.set(safe).await()
            Result.success(docRef.id)
        } catch (e: Exception) {
            Result.failure(Exception("বিজ্ঞাপন জমা দেওয়া যায়নি: ${e.localizedMessage ?: "ত্রুটি"}"))
        }
    }

    // ---------- 7. LOST & FOUND ----------
    fun observeLostFound(): Flow<ResourceState<List<LostFoundItem>>> = observeCollection(
        collectionName = "lost_found",
        queryBuilder = { it.collection("lost_found").limit(100) },
        mapDoc = { id, item -> item.copy(id = id) },
        sortKey = { it.createdAt }
    )

    suspend fun createLostFoundItem(item: LostFoundItem): Result<String> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            val docRef = firestore.collection("lost_found").document()
            val safe = item.copy(id = docRef.id, createdAt = System.currentTimeMillis())
            docRef.set(safe).await()
            Result.success(docRef.id)
        } catch (e: Exception) {
            Result.failure(Exception("তথ্য জমা দেওয়া যায়নি: ${e.localizedMessage ?: "ত্রুটি"}"))
        }
    }

    // ---------- 8. AREA PROBLEM REPORTS ----------
    fun observeAllReports(): Flow<ResourceState<List<AreaReport>>> = observeCollection(
        collectionName = "reports",
        queryBuilder = { it.collection("reports").limit(100) },
        mapDoc = { id, item -> item.copy(id = id) },
        sortKey = { it.createdAt }
    )

    fun observeMyReports(userId: String): Flow<ResourceState<List<AreaReport>>> {
        if (userId.isBlank()) return flowOf(ResourceState.Success(emptyList()))
        return observeCollection(
            collectionName = "reports",
            queryBuilder = { it.collection("reports").whereEqualTo("reporterId", userId).limit(100) },
            mapDoc = { id, item -> item.copy(id = id) },
            sortKey = { it.createdAt }
        )
    }

    suspend fun createReport(report: AreaReport): Result<String> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            val docRef = firestore.collection("reports").document()
            val now = System.currentTimeMillis()
            val safe = report.copy(
                id = docRef.id,
                status = "submitted",
                adminNote = "",
                createdAt = now,
                updatedAt = now
            )
            docRef.set(safe).await()
            Result.success(docRef.id)
        } catch (e: Exception) {
            Result.failure(Exception("অভিযোগ জমা দেওয়া যায়নি: ${e.localizedMessage ?: "ত্রুটি"}"))
        }
    }

    // ---------- 9. NOTIFICATIONS ----------
    fun observeNotifications(userId: String): Flow<ResourceState<List<AppNotification>>> {
        val firestore = db ?: return flowOf(ResourceState.Error(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        val targets = if (userId.isNotBlank()) listOf("all", userId) else listOf("all")
        return observeCollection(
            collectionName = "notifications",
            queryBuilder = { it.collection("notifications").whereIn("targetUserId", targets).limit(100) },
            mapDoc = { id, item -> item.copy(id = id) },
            sortKey = { it.createdAt }
        )
    }

    suspend fun markNotificationRead(notificationId: String): Result<Unit> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            firestore.collection("notifications").document(notificationId)
                .update("isRead", true).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------- 10. AREAS ----------
    fun observeAreas(): Flow<ResourceState<List<AreaInfo>>> = observeCollection(
        collectionName = "areas",
        queryBuilder = { it.collection("areas").limit(100) },
        mapDoc = { id, item -> item.copy(id = id) },
        sortKey = { if (it.id == "patgram_lalmonirhat") Long.MAX_VALUE else 0L }
    )
}
