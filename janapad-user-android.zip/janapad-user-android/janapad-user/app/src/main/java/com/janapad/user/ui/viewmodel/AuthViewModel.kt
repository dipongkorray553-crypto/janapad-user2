package com.janapad.user.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.janapad.user.data.local.PreferencesManager
import com.janapad.user.data.model.SelectedArea
import com.janapad.user.data.model.UserProfile
import com.janapad.user.data.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class AuthUiState(
    val isFirebaseReady: Boolean = false,
    val isCheckingSession: Boolean = true,
    val isLoggedIn: Boolean = false,
    val isLoading: Boolean = false,
    val userProfile: UserProfile? = null,
    val errorMessage: String? = null,
    val successMessage: String? = null
)

class AuthViewModel(application: Application) : AndroidViewModel(application) {

    private val authRepo = AuthRepository(application.applicationContext)
    private val prefs = PreferencesManager(application.applicationContext)

    private val _uiState = MutableStateFlow(AuthUiState(isFirebaseReady = authRepo.isFirebaseReady))
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    init {
        observeAuth()
    }

    private fun observeAuth() {
        viewModelScope.launch {
            authRepo.observeAuthState().collect { fbUser ->
                if (fbUser == null) {
                    _uiState.value = _uiState.value.copy(
                        isFirebaseReady = authRepo.isFirebaseReady,
                        isCheckingSession = false,
                        isLoggedIn = false,
                        userProfile = null
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isFirebaseReady = authRepo.isFirebaseReady,
                        isCheckingSession = false,
                        isLoggedIn = true
                    )
                    loadUserProfile(fbUser.uid)
                }
            }
        }
    }

    fun loadUserProfile(uid: String) {
        viewModelScope.launch {
            authRepo.fetchUserProfile(uid).onSuccess { profile ->
                _uiState.value = _uiState.value.copy(userProfile = profile)
            }
        }
    }

    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _uiState.value = _uiState.value.copy(errorMessage = "ইমেইল এবং পাসওয়ার্ড উভয়ই লিখুন।")
            return
        }
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null, successMessage = null)
            authRepo.login(email, password)
                .onSuccess { profile ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        isLoggedIn = true,
                        userProfile = profile,
                        successMessage = "সফলভাবে লগইন হয়েছে।"
                    )
                }
                .onFailure { e ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = e.message ?: "লগইন ব্যর্থ হয়েছে।"
                    )
                }
        }
    }

    fun register(name: String, phone: String, email: String, password: String, confirmPassword: String) {
        when {
            name.isBlank() -> {
                _uiState.value = _uiState.value.copy(errorMessage = "আপনার পূর্ণ নাম লিখুন।")
                return
            }
            phone.trim().length < 11 -> {
                _uiState.value = _uiState.value.copy(errorMessage = "সঠিক ১১ ডিজিটের মোবাইল নম্বর লিখুন।")
                return
            }
            email.isBlank() -> {
                _uiState.value = _uiState.value.copy(errorMessage = "সঠিক ইমেইল লিখুন।")
                return
            }
            password.length < 6 -> {
                _uiState.value = _uiState.value.copy(errorMessage = "পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।")
                return
            }
            password != confirmPassword -> {
                _uiState.value = _uiState.value.copy(errorMessage = "পাসওয়ার্ড দুটি মিলছে না।")
                return
            }
        }
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null, successMessage = null)
            val area = prefs.selectedAreaFlow.first()
            authRepo.register(name, phone, email, password, area)
                .onSuccess { profile ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        isLoggedIn = true,
                        userProfile = profile,
                        successMessage = "অ্যাকাউন্ট সফলভাবে তৈরি হয়েছে।"
                    )
                }
                .onFailure { e ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = e.message ?: "রেজিস্ট্রেশন ব্যর্থ হয়েছে।"
                    )
                }
        }
    }

    fun sendPasswordReset(email: String) {
        if (email.isBlank()) {
            _uiState.value = _uiState.value.copy(errorMessage = "আপনার নিবন্ধিত ইমেইল লিখুন।")
            return
        }
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null, successMessage = null)
            authRepo.sendPasswordReset(email)
                .onSuccess {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        successMessage = "পাসওয়ার্ড রিসেট লিংক আপনার ইমেইলে পাঠানো হয়েছে।"
                    )
                }
                .onFailure { e ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = e.message ?: "ইমেইল পাঠানো যায়নি।"
                    )
                }
        }
    }

    fun updateProfile(
        name: String,
        phone: String,
        district: String,
        upazila: String,
        union: String,
        ward: String,
        village: String,
        onComplete: (Boolean, String) -> Unit
    ) {
        val current = _uiState.value.userProfile ?: return
        viewModelScope.launch {
            val updated = current.copy(
                name = name.trim(),
                phone = phone.trim(),
                district = district.trim(),
                upazila = upazila.trim(),
                union = union.trim(),
                ward = ward.trim(),
                village = village.trim()
            )
            authRepo.updateUserProfile(updated)
                .onSuccess {
                    _uiState.value = _uiState.value.copy(userProfile = it)
                    onComplete(true, "প্রোফাইল সফলভাবে আপডেট হয়েছে।")
                }
                .onFailure { e ->
                    onComplete(false, e.message ?: "আপডেট করা যায়নি।")
                }
        }
    }

    fun syncSelectedAreaToProfile(area: SelectedArea) {
        val current = _uiState.value.userProfile ?: return
        viewModelScope.launch {
            val updated = current.copy(
                areaId = area.areaId,
                district = area.district,
                upazila = area.upazila,
                union = area.union,
                ward = area.ward,
                village = area.village
            )
            authRepo.updateUserProfile(updated).onSuccess {
                _uiState.value = _uiState.value.copy(userProfile = it)
            }
        }
    }

    fun logout() {
        authRepo.logout()
        _uiState.value = _uiState.value.copy(
            isLoggedIn = false,
            userProfile = null,
            errorMessage = null,
            successMessage = null
        )
    }

    fun clearMessages() {
        _uiState.value = _uiState.value.copy(errorMessage = null, successMessage = null)
    }
}
