# Keep Firestore data models
-keep class com.janapad.user.data.model.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
