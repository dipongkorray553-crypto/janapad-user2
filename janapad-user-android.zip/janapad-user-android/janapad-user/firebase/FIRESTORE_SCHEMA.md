# JANAPAD — Cloud Firestore Data Schema (১১টি Collection)

| Collection | মূল ফিল্ডসমূহ | নিরাপত্তা নীতি |
|---|---|---|
| `users/{uid}` | `uid`, `name`, `email`, `phone`, `role` (`"user"` / `"admin"`), `district`, `upazila`, `union`, `ward`, `village`, `areaId`, `createdAt`, `updatedAt` | ব্যবহারকারী নিজের প্রোফাইল আপডেট করতে পারবে, কিন্তু `role` পরিবর্তন করতে পারবে না। |
| `posts/{postId}` | `id`, `authorId`, `authorName`, `authorPhone`, `title`, `content`, `category`, `areaId`, `areaName`, `status` (`pending`/`approved`/`rejected`), `rejectionReason`, `createdAt`, `updatedAt` | নতুন পোস্ট বাধ্যতামূলকভাবে `pending` হবে। শুধু Admin অনুমোদন/বাতিল করতে পারবে। |
| `news/{newsId}` | `id`, `title`, `summary`, `content`, `category`, `isPinned`, `areaId`, `areaName`, `authorName`, `publishedAt`, `createdAt` | সবাই পড়তে পারবে; শুধু Admin তৈরি/সম্পাদনা/মুছতে পারবে। |
| `notices/{noticeId}` | `id`, `title`, `content`, `priority` (`high`/`normal`), `department`, `areaId`, `areaName`, `validUntil`, `createdAt` | সবাই পড়তে পারবে; শুধু Admin প্রকাশ করতে পারবে। |
| `blood_donors/{uid}` | `id`, `userId`, `name`, `bloodGroup`, `phone`, `consentToShowPhone`, `district`, `upazila`, `union`, `village`, `areaId`, `isAvailable`, `lastDonationDate`, `updatedAt` | দাতার সম্মতি (`consentToShowPhone == true`) ছাড়া ফোন নম্বর প্রকাশিত হয় না। |
| `jobs/{jobId}` | `id`, `title`, `companyName`, `category`, `salary`, `location`, `areaId`, `description`, `requirements`, `contactPhone`, `contactEmail`, `deadline`, `isActive`, `createdAt` | সবাই পড়তে পারবে; শুধু Admin প্রকাশ/আপডেট করতে পারবে। |
| `marketplace/{itemId}` | `id`, `sellerId`, `sellerName`, `title`, `description`, `price`, `category`, `condition`, `location`, `areaId`, `sellerPhone`, `status`, `createdAt` | নতুন বিজ্ঞাপন `pending` অবস্থায় জমা হয়; Admin অনুমোদনের পর সবাই দেখতে পায়। |
| `lost_found/{entryId}` | `id`, `reporterId`, `reporterName`, `type` (`lost`/`found`), `title`, `description`, `location`, `areaId`, `dateText`, `contactPhone`, `isResolved`, `createdAt` | লগইনকৃত ব্যবহারকারী রিপোর্ট করতে পারবে ও নিজের রিপোর্ট আপডেট/মুছতে পারবে। |
| `reports/{reportId}` | `id`, `reporterId`, `reporterName`, `category` (`road`/`electricity`/`water`/`drainage`/`public_service`), `title`, `description`, `locationDetail`, `areaId`, `areaName`, `status`, `adminNote`, `createdAt`, `updatedAt` | ব্যবহারকারী `submitted` স্ট্যাটাসে জমা দেবে; শুধু Admin স্ট্যাটাস আপডেট করতে পারবে। |
| `notifications/{id}` | `id`, `targetUserId` (`uid` বা `"all"`), `areaId`, `type`, `title`, `message`, `referenceId`, `isRead`, `createdAt` | ব্যবহারকারী নিজের ও সর্বজনীন নোটিফিকেশন পড়তে পারবে। |
| `areas/{areaId}` | `id`, `division`, `district`, `upazila`, `isActive`, `description`, `unions`, `emergencyContacts` | নতুন উপজেলা যুক্ত করলে অ্যাপে স্বয়ংক্রিয়ভাবে যুক্ত হয়ে যাবে। |
